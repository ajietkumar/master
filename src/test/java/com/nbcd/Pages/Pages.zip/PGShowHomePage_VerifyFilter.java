package com.nbcd.Pages;

//===============================================PACKAGES==========================================================================
import com.relevantcodes.extentreports.LogStatus;
import java.net.MalformedURLException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Utilities;

//==============================================================CLASSES AND METHODS==================================================
public class PGShowHomePage_VerifyFilter extends GetWebDriverInstance
{

//=========================================Variables=================================================================================
	static WebDriver driver;
	String sql;
	protected static String showDetails,screenshotExtension;
	DatabaseFunction db = new DatabaseFunction();
	public List<String> lstObject,lstTestData;
	String sqlQry,Status;
	WebElement objFilter_Section,objdrop_down;
	List<WebElement> objlist_size,objList_item;
	
	
//=================================================================================================================================================================================	
//Constructor to initialize all the Page Objects  
	public PGShowHomePage_VerifyFilter(String Browser) throws Exception 
	{      
		try 
			{
				
				PGShowHomePage_VerifyFilter.driver = GetWebDriverInstance.getBrowser(Browser);
				lstTestData=db.getTestDataObject("Select * from VerifyFilter","Input");
				lstObject=db.getTestDataObject("Select * from VerifyFilter","ObjectRepository");
				
			} 
			catch (MalformedURLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
					
					
		}
//========================================================================BUSINESS VALIDATION LOGIC=================================================
	@Test
		  public PGShowHomePage_VerifyFilter VerifyFilter( ) throws InterruptedException, FilloException 
		  {
				
			//Launching Browser with valid URL.
			     driver.get(lstTestData.get(0));
			     Actions act = new Actions(driver);
			     try {
						screenshotExtension=Extent_Reports.getScreenshot(driver);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			//Reading Objects
			try
			 {
				WebElement Filter_Section = Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(0);
				((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green'", Filter_Section);
	              boolean searchFilter = Filter_Section.isDisplayed();
				if (searchFilter == false)
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(1) +"':"+lstTestData.get(1) +Extent_Reports.logActual+lstObject.get(1) +"':"+Filter_Section.getAttribute("content"));
				}
				else
				{	
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(1) +"':"+lstTestData.get(1) +Extent_Reports.logActual+lstObject.get(1) +"':"+Filter_Section.getAttribute("content"));
					objdrop_down=Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
					act.moveToElement(objdrop_down).click().build().perform();
					//List<WebElement> list_size = driver.findElements(By.cssSelector("#main > section > div > section:nth-of-type(1) > div > div:nth-of-type(1) > div > div > ul > li.filter-select__item"));
					objlist_size=Utilities.returnElements(driver,lstObject.get(8),lstObject.get(7));
					objList_item=Utilities.returnElements(driver,lstObject.get(11),lstObject.get(10));
						for (int i=1;i<=objlist_size.size();i++){
								System.out.println(objList_item.get(i).getAttribute("innerHTML"));
					}
					
				} 	

				}
				
			
			 catch(Exception exc)
			 {
				 System.out.println(exc.getMessage());
			 }
			
			driver.close(); 
			
			return null;
		}
				
	
	  
}
