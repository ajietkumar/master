package com.nbcd.Pages;

//===============================================PACKAGES==========================================================================
import com.relevantcodes.extentreports.LogStatus;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Synchronization;
import com.nbcd.GenericLib.Utilities;

//==============================================================CLASSES AND METHODS==================================================
public class PGSchedulePage extends GetWebDriverInstance
{

//=========================================Variables=================================================================================
	static WebDriver driver;
	String sql;
	protected static String showDetails,screenshotExtension;
	DatabaseFunction db = new DatabaseFunction();
	public List<String> lstObject,lstTestData;
	String sqlQry,Status,Show_home,Schedule_Vedio_text,Schedule_vedio_homePage,WeekDay,WeekDate,month,date,WeekStartDay,ActualWeekDay,ActualStartDay;
	boolean Livelink;
	WebElement objSchedule_menu,objdescription,objcanonical,objtitle,objSchedule_video,objWatchlive,objDay,objDate,objSDay,objRightArrow,objLeftArrow;
	List<WebElement> Week_view,Following_week;
	ArrayList<String> list1,list2,list3,list4;
	
//=================================================================================================================================================================================	
//Constructor to initialize all the Page Objects  
	public PGSchedulePage(String Browser) throws Exception 
	{      
		try 
			{
				
				PGSchedulePage.driver = GetWebDriverInstance.getBrowser(Browser);
				lstTestData=db.getTestDataObject("Select * from PGSchedulePage","Input");
				lstObject=db.getTestDataObject("Select * from PGSchedulePage","ObjectRepository");
				
			} 
			catch (MalformedURLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
					
					
		}
//========================================================================BUSINESS VALIDATION LOGIC=================================================
	@Test
		  public PGSchedulePage VerifySEO_DBB_3825( ) throws InterruptedException, FilloException 
		  {
				
			//Launching Browser with valid URL.
			     driver.get(lstTestData.get(0));
			     try {
						screenshotExtension=Extent_Reports.getScreenshot(driver);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			//Reading Objects
			try
			 {
				objSchedule_menu =Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
				objSchedule_menu.click();
				Synchronization.implicitWait(driver, 50);
				System.out.println(driver.getCurrentUrl());;
				objdescription =Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
				objtitle=Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
				objcanonical=Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
				
								
			/**Description*/
				
				if (lstTestData.get(1).equalsIgnoreCase(objdescription.getAttribute("content")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + lstObject.get(4) +"':"+lstTestData.get(1) +Extent_Reports.logActual +lstObject.get(4) +"':"+objdescription.getAttribute("content"));
				}	
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + lstObject.get(4) +"':"+lstTestData.get(1) +Extent_Reports.logActual +lstObject.get(4) +"':"+objdescription.getAttribute("content"));

				}
				
				/**title*/
				if (lstTestData.get(2).equalsIgnoreCase(objcanonical.getAttribute("innerHTML")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected +lstObject.get(7) +"':"+lstTestData.get(2) +Extent_Reports.logActual+lstObject.get(7) +"':"+objcanonical.getAttribute("content"));
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected +lstObject.get(7) +"':"+lstTestData.get(2) +Extent_Reports.logActual+lstObject.get(7) +"':"+objcanonical.getAttribute("content"));

				}

			/**canonical*/	
				if (lstTestData.get(3).equalsIgnoreCase(objtitle.getAttribute("href")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected +lstObject.get(10) +"':"+lstTestData.get(3) +Extent_Reports.logActual+lstObject.get(10) +"':"+objtitle.getAttribute("content"));
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(10) +"':"+lstTestData.get(3) +Extent_Reports.logActual+lstObject.get(10) +"':"+objtitle.getAttribute("content"));

				}
				
						
					 }
			 catch(Exception exc)
			 {
				 System.out.println(exc.getMessage());
			 }
			
			driver.close(); 
			
			return null;
		}
	
	
	//------------------------------------Verify Show Name Links to Responsive Show Home page in Schedule Page (NBCRESP - 1213) ------------------------			
	@Test
	  public PGSchedulePage Verify_Responsive_Show_NBCRESP_1213( ) throws InterruptedException, FilloException 
	  {
			
		//Launching Browser with valid URL.
		     driver.get(lstTestData.get(0));
		     try {
					screenshotExtension=Extent_Reports.getScreenshot(driver);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		//Reading Objects
		try
		 {
			objSchedule_menu =Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
			objSchedule_menu.click();
			Synchronization.implicitWait(driver, 50);
			Show_home=driver.getCurrentUrl();
			
			/**schedule home page*/
			
			if (lstTestData.get(6).equalsIgnoreCase(Show_home))
			{
				Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + Show_home +"':"+ Extent_Reports.logActual + lstTestData.get(6) );
			}	
			else
			{
				Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + Show_home +"':"+ Extent_Reports.logActual + lstTestData.get(6));

			}	
			
						
			/**schedule video home page*/
			
			objSchedule_video=Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(0);
			Schedule_Vedio_text=objSchedule_video.getAttribute("innerHTML");
			objSchedule_video.click();
			Synchronization.implicitWait(driver, 50);
			Schedule_vedio_homePage=driver.getCurrentUrl();
			
			if (Schedule_Vedio_text.equalsIgnoreCase(Schedule_vedio_homePage))
			{
				Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + Schedule_vedio_homePage +"':"+ Extent_Reports.logActual + Schedule_Vedio_text );
			}	
			else
			{
				Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + Schedule_vedio_homePage +"':"+ Extent_Reports.logActual + Schedule_Vedio_text);

			}	

					
				 }
		 catch(Exception exc)
		 {
			 System.out.println(exc.getMessage());
		 }
		
		driver.close(); 
		
		return null;
	}

	  
	//------------------------------------ "Watch Live Now" CTA link is clicked from a schedule page in eligible DMA region (NBCRESP-1956) ------------------------			
		@Test
		  public PGSchedulePage  Verify_Watch_Live_Now ( ) throws InterruptedException, FilloException 
		  {
				
			//Launching Browser with valid URL.
			     driver.get(lstTestData.get(0));
			     try {
						screenshotExtension=Extent_Reports.getScreenshot(driver);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			//Reading Objects
			try
			 {
				objSchedule_menu =Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
				objSchedule_menu.click();
				Synchronization.implicitWait(driver, 50);
				objWatchlive=Utilities.returnElement(driver,lstObject.get(17),lstObject.get(16));
				Livelink = objWatchlive.isDisplayed();
				objWatchlive.click();
				Synchronization.implicitWait(driver, 50);
				Show_home=driver.getCurrentUrl();
				
								
			/**Show schedule video home page*/
				
				if (lstTestData.get(5).equalsIgnoreCase(Show_home))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + Show_home +"':"+ Extent_Reports.logActual + lstTestData.get(5) );
				}	
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + Show_home +"':"+ Extent_Reports.logActual + lstTestData.get(5));

				}			
						
					 }
			 catch(Exception exc)
			 {
				 System.out.println(exc.getMessage());
			 }
			
			driver.close(); 
			
			return null;
		}

		//------------------------------------ "Watch Live Now" CTA link is clicked from a schedule page in eligible DMA region (NBCRESP-1956) ------------------------			
		@Test
		  public PGSchedulePage  Verify_visitSiteLink ( ) throws InterruptedException, FilloException 
		  {
				
			//Launching Browser with valid URL.
			     driver.get(lstTestData.get(0));
			     try {
						screenshotExtension=Extent_Reports.getScreenshot(driver);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			//Reading Objects
			try
			 {
				//Click on Schedule link
				WebElement objSchedule = Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(3);
				objSchedule.click();
				Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Schedule link should be clicked"+Extent_Reports.logActual+"Schedule link is clicked");
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				//verify Visit Site arrow and text
				WebElement objVisitSite = Utilities.returnElements(driver,lstObject.get(23),lstObject.get(22)).get(2);
				String txtVisitSite= objVisitSite.getText();
				System.out.println(txtVisitSite);
				
				if(txtVisitSite.equalsIgnoreCase("VISIT SITE"))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"VISIT SITE text should be displayed"+Extent_Reports.logActual+"VISIT SITE text is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"VISIT SITE text should be displayed"+Extent_Reports.logActual+"VISIT SITE text is not displayed");
				}
				System.out.println(txtVisitSite);
				Actions act = new Actions(driver); 
				if(objVisitSite.isDisplayed())
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"VISIT SITE Arrow should be displayed"+Extent_Reports.logActual+"VISIT SITE Arrow is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"VISIT SITE Arrow should be displayed"+Extent_Reports.logActual+"VISIT SITE Arrow is not displayed");
				}
				System.out.println("loki");
				act.moveToElement(objVisitSite).click().build().perform();
				Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Visit site should be clickable"+Extent_Reports.logActual+"VISIT SITE Arrow is clicked");						
					 }
			 catch(Exception exc)
			 {
				 System.out.println(exc.getMessage());
			 }
			
			driver.close(); 
			
			return null;
		}
		//------------------------------------ "New Responsive Web Site -  Verify the navigation from date to date in Timeline in the Schedule Page (DBB-3815) ------------------------			
				@Test
				  public PGSchedulePage  Verify_SchedulePage_Timeline ( ) throws InterruptedException, FilloException 
				  {
						
					//Launching Browser with valid URL.
					     driver.get(lstTestData.get(0));
					     try {
								screenshotExtension=Extent_Reports.getScreenshot(driver);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					    
					//Reading Objects
					try
					 {
						//Click on Schedule link
						WebElement objSchedule = Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(3);
						objSchedule.click();
						Synchronization.implicitWait(driver, 30);
						screenshotExtension=Extent_Reports.getScreenshot(driver);
						
						objDay=Utilities.returnElement(driver,lstObject.get(29),lstObject.get(28));
						WeekDay=objDay.getAttribute("innerHTML");
						
						Date now = new Date();
						SimpleDateFormat simpleDateformat = new SimpleDateFormat("E"); // the day of the week abbreviated
				        ActualWeekDay = simpleDateformat.format(now);
											
						if(WeekDay.equalsIgnoreCase(ActualWeekDay))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+ "Week Day is:"+ WeekDay +Extent_Reports.logActual+ "Week Day is:"+ ActualWeekDay );
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+ "Week Day is:"+ WeekDay +Extent_Reports.logActual+ "Week Day is:"+ ActualWeekDay );
						}

						objDate=Utilities.returnElement(driver,lstObject.get(32),lstObject.get(31));
						WeekDate = objDate.getText();
						System.out.println(WeekDate);
						String[] s = WeekDate.split(" ");
						String month = s[0];
						String date = s[1];
						System.out.println(month);
						System.out.println(date);
						Calendar cal = Calendar.getInstance();
						SimpleDateFormat simpleDateformat1 = new SimpleDateFormat("MMM");
						Date date1 = cal.getTime();
						int Actualdate = cal.get(Calendar.DATE);
						String ActualdateMonth = simpleDateformat1.format(cal.getTime());
						System.out.println(Actualdate);
						System.out.println(ActualdateMonth);
						if(month.equalsIgnoreCase((ActualdateMonth)))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+ "Month is :"+ month +Extent_Reports.logActual+ "Month is :"+ ActualdateMonth );
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+ "Month is :"+ month +Extent_Reports.logActual+ "Month is :"+ ActualdateMonth);
						}

						if(date.equalsIgnoreCase(Integer.toString(Actualdate)))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+ "Date is :" + date +Extent_Reports.logActual+ "Date is :"+ Integer.toString(Actualdate) );
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+ "Date is :"+  date +Extent_Reports.logActual+ "Date is :"+ Integer.toString(Actualdate));
						}

						
						Week_view = Utilities.returnElements(driver,lstObject.get(35),lstObject.get(34));
						list1 = new ArrayList<String>();
						list2 = new ArrayList<String>();
						System.out.println(Week_view.size());
						
						if(Week_view.size()==7)
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+ Week_view.size() +Extent_Reports.logActual+ 7 );
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+  Week_view.size() +Extent_Reports.logActual+ 7 );
						}

						for (int l=0;l<Week_view.size();l++){
							list1.add(Week_view.get(l).getText());
							System.out.println("Default week Date is" + (Week_view.get(l).getText()));
						}
						
						for(int i = Calendar.SUNDAY; i <= Calendar.SATURDAY; i++)
						{
					    cal.set(Calendar.DAY_OF_WEEK, i);
					    Date date2 = cal.getTime();
					    SimpleDateFormat formatter = new SimpleDateFormat("MMM dd");
					    String formattedDate = formatter.format(date2);
				        System.out.println(formattedDate);
					    list2.add(formattedDate);
						}
						
					   for (String a : list1)
					    {
					        for (String b : list2)
					        {
					           
					            if(a.equalsIgnoreCase(b))
								{
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+ "Default Week Days of NBC matched with System Default Week Days " + a + Extent_Reports.logActual+ "Default Week Days of matched with System Default Week Days "+ b );
									break;
								}
							
					        }
					    }
					    
					    objSDay = Utilities.returnElement(driver,lstObject.get(38),lstObject.get(37));
						WeekStartDay = objSDay.getAttribute("innerHTML");
						ActualStartDay="sun";
						if(WeekStartDay.equalsIgnoreCase(ActualStartDay))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+ WeekStartDay +Extent_Reports.logActual+ ActualStartDay );
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+  WeekStartDay +Extent_Reports.logActual+ ActualStartDay );
						}
						
										
						objRightArrow = Utilities.returnElement(driver,lstObject.get(41),lstObject.get(40));
						objRightArrow.click();
						Synchronization.implicitWait(driver, 30);
						screenshotExtension=Extent_Reports.getScreenshot(driver);
						Following_week = Utilities.returnElements(driver,lstObject.get(44),lstObject.get(43));
						list3 = new ArrayList<String>();
						System.out.println(Following_week.size());
						for (int j=0;j<Following_week.size();j++){
							list3.add(Following_week.get(j).getText());
							System.out.println("Following week Date is:" + (Following_week.get(j).getText()));
						}
						list4 = new ArrayList<String>();
						SimpleDateFormat sdf = new SimpleDateFormat("MMM dd");
						for (int i = 6; i < 13; i++) {
						    Calendar calendar = new GregorianCalendar();
						    calendar.add(Calendar.DATE, i);
						    String day = sdf.format(calendar.getTime());
						    list4.add(day);
						 	}
						
						for (String c : list3)
					    {
					        for (String d : list4)
					        {
					           	if(c.equalsIgnoreCase(d))
								{
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+ "Next Week Days of NBC matched with System Default Week Days" + c + Extent_Reports.logActual+"Next Week Days of NBC matched with System Default Week Days"+  d );
									break;
								}
								
					        }
					    }
					
						objLeftArrow = Utilities.returnElement(driver,lstObject.get(47),lstObject.get(46));
						objLeftArrow.click();
						Synchronization.implicitWait(driver, 30);
						screenshotExtension=Extent_Reports.getScreenshot(driver);
						Week_view = Utilities.returnElements(driver,lstObject.get(35),lstObject.get(34));
						for (int k=0;k<Week_view.size();k++){
							list1.add(Week_view.get(k).getText());
							//System.out.println("Default week Date is" + (Week_view.get(k).getText()));
						}
						
						for (String a : list1)
					    {
					        for (String b : list2)
					        {
					        	 if(a.equalsIgnoreCase(b))
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+ "Default Week Days of NBC matched with System Default Week Days" + a + Extent_Reports.logActual+ "Default Week Days of NBC matched with System Default Week Days "+ b );
										break;
									}
									

					        }
					    }
					 
				
					 
					 }
					 catch(Exception exc)
					 {
						 System.out.println(exc.getMessage());
					 }
					
					driver.close(); 
					
					return null;
				}


}
