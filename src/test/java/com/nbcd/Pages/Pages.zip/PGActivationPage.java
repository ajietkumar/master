package com.nbcd.Pages;

import java.net.MalformedURLException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Utilities;
import com.relevantcodes.extentreports.LogStatus;

public class PGActivationPage {

//=========================================Variables=================================================================================
		private static WebDriver driver;
		DatabaseFunction db = new DatabaseFunction();
		public List<String> lstObject,lstTestData;
		static String screenshotExtension;
		String sqlQry,Status,strResultText,sql,strlinkType;
		WebElement objAppLink,objActivateLink,objEnterCode,objContinue,objConDis,objErrMsg,objVal,objGenerateCode;
		WebElement objMvpdActLogo,objMvpdActBack,objMvpdActFooter,objUserName,objPassword,objSignin,objSucessCheckMarck;
		int iActivateLinkCnt,iLoop ;
		
//=================================================================================================================================================================================	
//Constructor to initialize all the Page Objects  
		public PGActivationPage(String Browser) 
		{      
			try 
				{
					
					this.driver = GetWebDriverInstance.getBrowser(Browser);
					lstTestData=db.getTestDataObject("Select * from ActivationPage","Input"); //Reading Input
					lstObject=db.getTestDataObject("Select * from ActivationPage","ObjectRepository"); 	//Reading Objects
				} 
				catch (MalformedURLException e) 
				{
					
					e.printStackTrace();
					
				} 
						
						
			}
//========================================================================BUSINESS VALIDATION LOGIC=================================================
		@Test
		  public PGActivationPage VerifyInvalidAndValidData( ) throws InterruptedException, FilloException 
		  {
				//Launching Browser with valid URL.
					  driver.get("https://www.nbc.com/apps");
				     try
				     {
				     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
				     screenshotExtension=Extent_Reports.getScreenshot(driver);
				     }
				     catch(Exception exc)
					 {
						 System.out.println(exc.getMessage());
					 }
					
			
				     try
					 {
					
				    	List <WebElement> objActivateLink =Utilities.returnElements(driver,lstObject.get(5),lstObject.get(4));
				    	iActivateLinkCnt = objActivateLink.size();
						
						for( iLoop=0;iLoop < iActivateLinkCnt;iLoop++)
						{
							strlinkType = objActivateLink.get(iLoop).getText();
						
							if(strlinkType.contentEquals("ACTIVATE"))
							{
								objActivateLink.get(iLoop).click();
								
								driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
								
								objEnterCode = Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
							
								if(objEnterCode.isDisplayed())
								{
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Enter code text box should be displayed"+ Extent_Reports.logActual+"Enter code text box is displayed");
								}
								else
								{
									Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Enter code text box should be displayed"+ Extent_Reports.logActual+"Enter code text box is not displayed");
								}
								
								String strDefaulttxt = objEnterCode.getAttribute("placeholder");
								
								if(strDefaulttxt.contentEquals("Enter your activation code"))
								{
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Default Text should display"+ Extent_Reports.logActual+"Default text is displaying as "+strDefaulttxt);
								}
								else
								{
									Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Default Text should display"+ Extent_Reports.logActual+"Default text is not displaying as "+strDefaulttxt);
								}
								objEnterCode.sendKeys("1234567");
								objContinue = Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
								if(objContinue.isDisplayed())
								{
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should display"+ Extent_Reports.logActual+"Continue Button is displayed ");
								}
								else
								{
									Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Continue button should display"+ Extent_Reports.logActual+"Continue Button is not displayed ");
								}
								//Validate if less than 7 characters
								objEnterCode.clear();
								objEnterCode.sendKeys("123456");
								objConDis = Utilities.returnElement(driver,lstObject.get(14),lstObject.get(13));
								System.out.println("lokiyht");
								if(objConDis.isEnabled())
								{
									Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Continue button should disabled"+ Extent_Reports.logActual+"Continue Button is enabled if less than 7 characters");
								}
								else
								{
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should disabled"+ Extent_Reports.logActual+"Continue Button is disabled if less than 7 characters");
								}
								
								objEnterCode.clear();
								//Validate if there 7 characters
								objEnterCode.sendKeys("1234567");
								if(objContinue.isEnabled())
								{
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should disabled"+ Extent_Reports.logActual+"Continue Button is enabled if 7 characters ");
								}
								else
								{
									Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Continue button should disabled"+ Extent_Reports.logActual+"Continue Button is disabled if 7 characters");
								}
								
								
								//Validate if again less than 7 characters previous 
								objEnterCode.sendKeys(Keys.BACK_SPACE);
								if(objConDis.isEnabled())	
								{
									Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Continue button should disabled"+ Extent_Reports.logActual+"Continue Button is enabled if less than 7 characters");
								}
								else
								{
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should disabled"+ Extent_Reports.logActual+"Continue Button is disabled if less than 7 characters");
								}
								
								 System.out.println("lolikputgh");
								 driver.navigate().to("https://www.nbc.com/apps");
								 System.out.println("lo000000h");
								 driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
								 System.out.println("lolikpdsfsdfsdfh");
								 JavascriptExecutor jse = (JavascriptExecutor) driver;
							     jse.executeScript("window.scrollBy(0,280)", "");
							     jse.executeScript("window.scrollBy(0,280)", "");
							     jse.executeScript("window.scrollBy(0,280)", "");
								 
								 
								 
							}
						}
					
					
				 }
				 catch(Exception exc)
				 {
					 System.out.println(exc.getMessage());
				 }
				
				//driver.close(); 
				
				return null;
			} 
		
		//========================================================================BUSINESS VALIDATION LOGIC=================================================
		@Test
		  public PGActivationPage VerifyErrorMessageInvalidcode( ) throws InterruptedException, FilloException 
		  {
			
				//Launching Browser with valid URL.
				     //driver.get(lstTestData.get(0));
					   driver.get("https://www.nbc.com/apps");
				     try
				     {
				     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
				     screenshotExtension=Extent_Reports.getScreenshot(driver);
				     }
				     catch(Exception exc)
					 {
						 System.out.println(exc.getMessage());
					 }
					
				//Reading Objects
				try
				 {
					
				
					List <WebElement> objActivateLink =Utilities.returnElements(driver,lstObject.get(5),lstObject.get(4));
					int objActivateLinkct = objActivateLink.size();
					System.out.println(objActivateLinkct);
					//for(int i=0;i<objActivateLinkct;i++)
					//{
						String StrlinkType = objActivateLink.get(2).getText();
						System.out.println(StrlinkType);
						//if(StrlinkType.contentEquals("ACTIVATE"))
						//{
							objActivateLink.get(2).click();
							driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							objEnterCode = Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
							if(objEnterCode.isDisplayed())
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Enter code text box should be displayed"+ Extent_Reports.logActual+"Enter code text box is displayed");
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Enter code text box should be displayed"+ Extent_Reports.logActual+"Enter code text box is not displayed");
							}
							
							String strDefaulttxt = objEnterCode.getAttribute("placeholder");
							System.out.println(objEnterCode.getAttribute("placeholder"));
							if(strDefaulttxt.contentEquals("Enter your activation code"))
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Default Text should display"+ Extent_Reports.logActual+"Default text is displaying as "+strDefaulttxt);
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Default Text should display"+ Extent_Reports.logActual+"Default text is not displaying as "+strDefaulttxt);
							}
							objEnterCode.sendKeys("1234567");
							objContinue = Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
							if(objContinue.isDisplayed())
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should display"+ Extent_Reports.logActual+"Continue Button is displayed ");
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Continue button should display"+ Extent_Reports.logActual+"Continue Button is not displayed ");
							}
							
							objContinue.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should clicked"+ Extent_Reports.logActual+"Continue Button is clicked ");
							driver.manage().timeouts().implicitlyWait(160, TimeUnit.SECONDS);
							objErrMsg = Utilities.returnElement(driver,lstObject.get(17),lstObject.get(16));
							String CompErrMsg = ("Your activation code has expired or is invalid. Please generate a new code from your device.");
							String txtErrorMessage = objErrMsg.getText();
							if(txtErrorMessage.contentEquals(CompErrMsg))
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Error Message should display"+ Extent_Reports.logActual+"Error Message is displayed and the error message is  "+txtErrorMessage);
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Error Message should display"+ Extent_Reports.logActual+"Error Message is not displayed as expected and the error message is  "+txtErrorMessage);
							}
							
							String colErrorMsg = objErrMsg.getCssValue("color");
							System.out.println(colErrorMsg);
							String color_hex[];  
							color_hex = colErrorMsg.replace("rgba(", "").split(",");       
							String actual_hexErr = String.format("#%02x%02x%02x", Integer.parseInt(color_hex[0].trim()), Integer.parseInt(color_hex[1].trim()), Integer.parseInt(color_hex[2].trim()));
							System.out.println(actual_hexErr);
							if(actual_hexErr.equalsIgnoreCase("#c20009"))
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Error Message should display in red color"+ Extent_Reports.logActual+"Error Message is displayed and is in red color ");
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Error Message should display in red color"+ Extent_Reports.logActual+"Error Message is displayed and is not in red color ");
							}
							String colCodeText = objEnterCode.getCssValue("color");
							System.out.println(colCodeText);
							color_hex = colErrorMsg.replace("rgba(", "").split(",");       
							String actual_hexCode = String.format("#%02x%02x%02x", Integer.parseInt(color_hex[0].trim()), Integer.parseInt(color_hex[1].trim()), Integer.parseInt(color_hex[2].trim()));
							System.out.println(actual_hexCode);
							if(actual_hexErr.equalsIgnoreCase("#c20009"))
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Enter code text box should display in red color"+ Extent_Reports.logActual+"Enter code text box is displayed and is in red color ");
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Enter code text box should display in red color"+ Extent_Reports.logActual+"Enter code text box is displayed and is not in red color ");
							}
							
						//}
					//}
					
					
				 }
				 catch(Exception exc)
				 {
					 System.out.println(exc.getMessage());
				 }
				
				driver.close(); 
				
				return null;
			} 	
		
//========================================================================BUSINESS VALIDATION LOGIC=================================================
				@Test
				  public PGActivationPage VerifyGeneralLayout( ) throws InterruptedException, FilloException 
				  {
					
						//Launching Browser with valid URL.
						     //driver.get(lstTestData.get(0));
							   driver.get("https://www.nbc.com/apps");
						     try
						     {
						     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
						     screenshotExtension=Extent_Reports.getScreenshot(driver);
						     }
						     catch(Exception exc)
							 {
								 System.out.println(exc.getMessage());
							 }
							
						//Reading Objects
						try
						 {
							
							/**driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							WebElement objAppLink =Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(6);
							objAppLink.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Apps Landing Page should display"+ Extent_Reports.logActual+"Apps Landing page is dispalyed after App link is clicked from global navigation");
							screenshotExtension=Extent_Reports.getScreenshot(driver);
							*/
							List <WebElement> objActivateLink =Utilities.returnElements(driver,lstObject.get(5),lstObject.get(4));
							int objActivateLinkct = objActivateLink.size();
							System.out.println(objActivateLinkct);
							//for(int i=0;i<objActivateLinkct;i++)
							//{
								String StrlinkType = objActivateLink.get(2).getText();
								System.out.println(StrlinkType);
								//if(StrlinkType.contentEquals("ACTIVATE"))
								//{
									objActivateLink.get(2).click();
									driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
									objEnterCode = Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
									if(objEnterCode.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Enter code text box should be displayed"+ Extent_Reports.logActual+"Enter code text box is displayed");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Enter code text box should be displayed"+ Extent_Reports.logActual+"Enter code text box is not displayed");
									}
									
									String strDefaulttxt = objEnterCode.getAttribute("placeholder");
									System.out.println(objEnterCode.getAttribute("placeholder"));
									if(strDefaulttxt.contentEquals("Enter your activation code"))
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Default Text should display"+ Extent_Reports.logActual+"Default text is displaying as "+strDefaulttxt);
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Default Text should display"+ Extent_Reports.logActual+"Default text is not displaying as "+strDefaulttxt);
									}
									
									driver.navigate().to("http://tvestaging-origin.nbcuni.com/device_activation_code.php");
									String ParentWindow = driver.getWindowHandle();
									Set<String> s1=driver.getWindowHandles();
									Iterator<String> nWindow= s1.iterator();
									while(nWindow.hasNext()){
										String childWindow = nWindow.next();
										driver.switchTo().window(childWindow);
									}
									Select objSelectEnv = new Select(Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(0));
									objSelectEnv.selectByIndex(1);
									Select objSelectBrand = new Select(Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(1));
									objSelectBrand.selectByIndex(7);
									objGenerateCode = Utilities.returnElement(driver,lstObject.get(23),lstObject.get(22));
									objGenerateCode.click();
									driver.getTitle();
									System.out.println(driver.getTitle());
									WebDriverWait wait= new WebDriverWait(driver,60);
									objVal = Utilities.returnElement(driver,lstObject.get(26),lstObject.get(25));
									wait.until(ExpectedConditions.visibilityOf(objVal));
									
									driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
									
									//objVal = Utilities.returnElement(driver,lstObject.get(26),lstObject.get(25));
								
									String valCode = objVal.getAttribute("innerHTML");
									System.out.println(valCode);
									System.out.println("JHYTGRR");
									//driver.switchTo().window(ParentWindow);
									driver.navigate().to("https://www.nbc.com/activate");
									driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
									
									objEnterCode.sendKeys(valCode);
									System.out.println("lkjumngffdeedd");
									objContinue = Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
									if(objContinue.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should display"+ Extent_Reports.logActual+"Continue Button is displayed ");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Continue button should display"+ Extent_Reports.logActual+"Continue Button is not displayed ");
									}
									
									objContinue.click();
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should clicked"+ Extent_Reports.logActual+"Continue Button is clicked ");
									driver.manage().timeouts().implicitlyWait(160, TimeUnit.SECONDS);
									String strTitle = driver.getTitle();
									System.out.println(strTitle);
									objMvpdActLogo =  Utilities.returnElement(driver,lstObject.get(29),lstObject.get(28));
									if(objMvpdActLogo.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Logo should display"+ Extent_Reports.logActual+"NBC Logo is displayed");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"NBC Logo should display"+ Extent_Reports.logActual+"NBC Logo is not displayed");
									}
									WebElement objMvpdActtitle =  Utilities.returnElements(driver,lstObject.get(32),lstObject.get(31)).get(1);
									if(objMvpdActtitle.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Title should display"+ Extent_Reports.logActual+"Title is displayed");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"NBC Logo should display"+ Extent_Reports.logActual+"NBC Logo is not displayed");
									}
									objMvpdActBack =  Utilities.returnElement(driver,lstObject.get(35),lstObject.get(34));
									if(objMvpdActBack.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Back link should display"+ Extent_Reports.logActual+"Back link is displayed");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Back link should display"+ Extent_Reports.logActual+"Back link is not displayed");
									}
									WebElement objMvpdActfaq =  Utilities.returnElements(driver,lstObject.get(38),lstObject.get(37)).get(1);
									if(objMvpdActfaq.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Need Help linking?See our FAQ. should display"+ Extent_Reports.logActual+"Need Help linking?See our FAQ. is displayed");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Need Help linking?See our FAQ. should display"+ Extent_Reports.logActual+"Need Help linking?See our FAQ. is not displayed");
									}
									objMvpdActFooter =  Utilities.returnElement(driver,lstObject.get(41),lstObject.get(40));
									if(objMvpdActFooter.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Back link should display"+ Extent_Reports.logActual+"Back link is displayed");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Back link should display"+ Extent_Reports.logActual+"Back link is not displayed");
									}
									
									
									
								//}
							//}
							
							
						 }
						 catch(Exception exc)
						 {
							 System.out.println(exc.getMessage());
						 }
						
						//driver.close(); 
						//Verify URL Pathing/Routing for activation page
						return null;
					} 		
		
//========================================================================BUSINESS VALIDATION LOGIC=================================================
				@Test
				  public PGActivationPage VerifyURLPathingRoutingactivation( ) throws InterruptedException, FilloException 
				  {
					
						//Launching Browser with valid URL.
						   	 driver.get(lstTestData.get(0));
							 /**driver.get("https://www.nbc.com/apps");
						     try
						     {
						     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
						     screenshotExtension=Extent_Reports.getScreenshot(driver);
						     }
						     catch(Exception exc)
							 {
								 System.out.println(exc.getMessage());
							 }*/
							
						//Reading Objects
						try
						 {
							
							//driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							driver.navigate().to(lstTestData.get(2));
							driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							String appletvredirURL = driver.getCurrentUrl();
							if(appletvredirURL.contentEquals("https://www.nbc.com/activate"))
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"URL should get redirected for URL"+ lstTestData.get(2)+Extent_Reports.logActual+"URL is redirected and the url is"+appletvredirURL);
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"URL should get redirected for URL"+lstTestData.get(2)+Extent_Reports.logActual+"URL is not redirected and the url is"+appletvredirURL);
							}
							
							driver.navigate().to(lstTestData.get(3));
							driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							String amazonredirURL = driver.getCurrentUrl();
							if(amazonredirURL.contentEquals("https://www.nbc.com/activate"))
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"URL should get redirected for URL "+lstTestData.get(3)+Extent_Reports.logActual+"URL is redirected and the url is"+appletvredirURL);
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"URL should get redirected for URL"+lstTestData.get(3)+Extent_Reports.logActual+"URL is not redirected and the url is"+appletvredirURL);
							}
							
							driver.navigate().to(lstTestData.get(4));
							driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							String rokudirURL = driver.getCurrentUrl();
							if(rokudirURL.contentEquals("https://www.nbc.com/activate"))
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"URL should get redirected for URL"+lstTestData.get(4)+Extent_Reports.logActual+"URL is redirected and the url is"+appletvredirURL);
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"URL should get redirected for URL"+lstTestData.get(4)+Extent_Reports.logActual+"URL is not redirected and the url is"+appletvredirURL);
							}
							
							driver.navigate().to(lstTestData.get(5));
							driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							String xboneonedirURL = driver.getCurrentUrl();
							if(xboneonedirURL.contentEquals("https://www.nbc.com/activate"))
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"URL should get redirected for URL"+lstTestData.get(5)+Extent_Reports.logActual+"URL is redirected and the url is"+appletvredirURL);
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"URL should get redirected for URL"+lstTestData.get(5)+Extent_Reports.logActual+"URL is not redirected and the url is"+appletvredirURL);
							}
							
							driver.navigate().to(lstTestData.get(6));
							driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							String xboxoneURL = driver.getCurrentUrl();
							if(xboxoneURL.contentEquals("https://www.nbc.com/activate?redir=xbox360"))
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"URL should get redirected for URL"+lstTestData.get(6)+Extent_Reports.logActual+"URL is redirected and the url is"+appletvredirURL);
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"URL should get redirected for URL"+lstTestData.get(6)+Extent_Reports.logActual+"URL is not redirected and the url is"+appletvredirURL);
							}
							
							
							
							
						 }
						 catch(Exception exc)
						 {
							 System.out.println(exc.getMessage());
						 }
						
						driver.close(); 
						
						return null;
					} 	
				
//========================================================================BUSINESS VALIDATION LOGIC=================================================
				@Test
				  public PGActivationPage VerifySucessPage( ) throws InterruptedException, FilloException 
				  {
					
						//Launching Browser with valid URL.
						     //driver.get(lstTestData.get(0));
							   driver.get("https://www.nbc.com/apps");
						     try
						     {
						     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
						     screenshotExtension=Extent_Reports.getScreenshot(driver);
						     }
						     catch(Exception exc)
							 {
								 System.out.println(exc.getMessage());
							 }
							
						//Reading Objects
						try
						 {
							
							/**driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							WebElement objAppLink =Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(6);
							objAppLink.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Apps Landing Page should display"+ Extent_Reports.logActual+"Apps Landing page is dispalyed after App link is clicked from global navigation");
							screenshotExtension=Extent_Reports.getScreenshot(driver);
							*/
							List <WebElement> objActivateLink =Utilities.returnElements(driver,lstObject.get(5),lstObject.get(4));
							int objActivateLinkct = objActivateLink.size();
							System.out.println(objActivateLinkct);
							//for(int i=0;i<objActivateLinkct;i++)
							//{
								String StrlinkType = objActivateLink.get(2).getText();
								System.out.println(StrlinkType);
								//if(StrlinkType.contentEquals("ACTIVATE"))
								//{
									objActivateLink.get(2).click();
									driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
									objEnterCode = Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
									if(objEnterCode.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Enter code text box should be displayed"+ Extent_Reports.logActual+"Enter code text box is displayed");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Enter code text box should be displayed"+ Extent_Reports.logActual+"Enter code text box is not displayed");
									}
									
									String strDefaulttxt = objEnterCode.getAttribute("placeholder");
									System.out.println(objEnterCode.getAttribute("placeholder"));
									if(strDefaulttxt.contentEquals("Enter your activation code"))
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Default Text should display"+ Extent_Reports.logActual+"Default text is displaying as "+strDefaulttxt);
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Default Text should display"+ Extent_Reports.logActual+"Default text is not displaying as "+strDefaulttxt);
									}
									
									driver.navigate().to("http://tvestaging-origin.nbcuni.com/device_activation_code.php");
									String ParentWindow = driver.getWindowHandle();
									Set<String> s1=driver.getWindowHandles();
									Iterator<String> nWindow= s1.iterator();
									while(nWindow.hasNext()){
										String childWindow = nWindow.next();
										driver.switchTo().window(childWindow);
									}
									Select objSelectEnv = new Select(Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(0));
									objSelectEnv.selectByIndex(1);
									Select objSelectBrand = new Select(Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(1));
									objSelectBrand.selectByIndex(7);
									objGenerateCode = Utilities.returnElement(driver,lstObject.get(23),lstObject.get(22));
									objGenerateCode.click();
									driver.getTitle();
									System.out.println(driver.getTitle());
									WebDriverWait wait= new WebDriverWait(driver,60);
									objVal = Utilities.returnElement(driver,lstObject.get(26),lstObject.get(25));
									wait.until(ExpectedConditions.visibilityOf(objVal));
									
									driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
									
									//objVal = Utilities.returnElement(driver,lstObject.get(26),lstObject.get(25));
								
									String valCode = objVal.getAttribute("innerHTML");
									System.out.println(valCode);
									System.out.println("JHYTGRR");
									//driver.switchTo().window(ParentWindow);
									driver.navigate().to("https://www.nbc.com/activate");
									driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
									
									objEnterCode.sendKeys(valCode);
									System.out.println("lkjumngffdeedd");
									objContinue = Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
									if(objContinue.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should display"+ Extent_Reports.logActual+"Continue Button is displayed ");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Continue button should display"+ Extent_Reports.logActual+"Continue Button is not displayed ");
									}
									
									objContinue.click();
									Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Continue button should clicked"+ Extent_Reports.logActual+"Continue Button is clicked ");
									driver.manage().timeouts().implicitlyWait(160, TimeUnit.SECONDS);
									String strTitle = driver.getTitle();
									System.out.println(strTitle);
									WebElement objMVPDOptium = Utilities.returnElements(driver,lstObject.get(44),lstObject.get(43)).get(8);
									objMVPDOptium.click();
									driver.manage().timeouts().implicitlyWait(160, TimeUnit.SECONDS);
									objUserName = Utilities.returnElement(driver,lstObject.get(50),lstObject.get(49));
									objUserName.sendKeys("research1000");
									objPassword = Utilities.returnElement(driver,lstObject.get(53),lstObject.get(52));
									objPassword.sendKeys("Support1000");
									objSignin = Utilities.returnElement(driver,lstObject.get(56),lstObject.get(55));
									objSignin.click();
									driver.manage().timeouts().implicitlyWait(160, TimeUnit.SECONDS);
									objSucessCheckMarck = Utilities.returnElement(driver,lstObject.get(47),lstObject.get(46));
									if(objSucessCheckMarck.isDisplayed())
									{
										Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Check Marck should display on Success Page"+ Extent_Reports.logActual+"Check Marck is displayed on Sucess Page");
									}
									else
									{
										Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Check Marck should display on Success Page"+ Extent_Reports.logActual+"Check Marck is not displayed on Sucess Page");
									}
										
										
									
								//}
							//}
							
							
						 }
						 catch(Exception exc)
						 {
							 System.out.println(exc.getMessage());
						 }
						
						//driver.close(); 
						//Verify URL Pathing/Routing for activation page
						return null;
					} 				
				
				
		
}

