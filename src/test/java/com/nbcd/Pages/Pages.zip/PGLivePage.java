package com.nbcd.Pages;

import java.net.MalformedURLException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Utilities;
import com.relevantcodes.extentreports.LogStatus;

public class PGLivePage {

	//=========================================Variables=================================================================================
		private static WebDriver driver;
		String sql;
		protected static String showDetails;
		DatabaseFunction db = new DatabaseFunction();
		public List<String> lstObject,lstTestData;
		static String screenshotExtension;
		String sqlQry,Status,strResultText;
		WebElement objLive,objOptimum,objOptLogin,objUserName,objPassword,objlogin,objoptlogo;
		
		
	//=================================================================================================================================================================================	
	//Constructor to initialize all the Page Objects  
		public PGLivePage(String Browser) 
		{      
			try 
				{
					
					this.driver = GetWebDriverInstance.getBrowser(Browser);
					lstTestData=db.getTestDataObject("Select * from LivePage","Input");
					lstObject=db.getTestDataObject("Select * from LivePage","ObjectRepository");
				} 
				catch (MalformedURLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
						
						
			}
	//========================================================================BUSINESS VALIDATION LOGIC=================================================
		@Test
		  public PGLivePage VerifyLivestreampageSupportedregion( ) throws InterruptedException, FilloException 
		  {
			
				//Launching Browser with valid URL.
				     driver.get(lstTestData.get(0));
				     try
				     {
				     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Browser should Launch"+Extent_Reports.logActual+"Browser Launch is succesfull");
				     screenshotExtension=Extent_Reports.getScreenshot(driver);
				     }
				     catch(Exception exc)
					 {
						 System.out.println(exc.getMessage());
					 }
					
				//Reading Objects
				try
				 {
					driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
					objLive =Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
					objLive.click();
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Live Page should display"+ Extent_Reports.logActual+"Live page is displayed after Live link is clicked from global navigation");
					screenshotExtension=Extent_Reports.getScreenshot(driver);
					Actions act = new Actions(driver); 
					
					//Click on TV provider link 
					objOptimum = Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
					act.moveToElement(objOptimum).click().build().perform();
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Provider Login page should display"+ Extent_Reports.logActual+"Provider login page is displayed");
					
					//Login screen validation
					String ParentWindow = driver.getWindowHandle();
					Set<String> s1=driver.getWindowHandles();
					Iterator<String> nWindow= s1.iterator();
					while(nWindow.hasNext()){
						String childWindow = nWindow.next();
						driver.switchTo().window(childWindow);
					}
					
					objOptLogin = Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
					if(objOptLogin.isDisplayed())
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Login page should display"+ Extent_Reports.logActual+"login page is displayed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Login page should display"+ Extent_Reports.logActual+"login page is not displayed");
					}
					
					
				 }
				 catch(Exception exc)
				 {
					 System.out.println(exc.getMessage());
				 }
				
				driver.close(); 
				
				return null;
			} 
		
		//========================================================================BUSINESS VALIDATION LOGIC=================================================
				@Test
				  public PGLivePage VerifyAuthSuccessMsgMVPDNBCRESP_1754( ) throws InterruptedException, FilloException 
				  {
					
						//Launching Browser with valid URL.
						     driver.get(lstTestData.get(0));
						     try
						     {
						     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Browser should Launch"+Extent_Reports.logActual+"Browser Launch is succesfull");
						     screenshotExtension=Extent_Reports.getScreenshot(driver);
						     }
						     catch(Exception exc)
							 {
								 System.out.println(exc.getMessage());
							 }
							
						//Reading Objects
						try
						 {
							driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
							objLive =Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
							objLive.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Live Page should display"+ Extent_Reports.logActual+"Live page is displayed after Live link is clicked from global navigation");
							screenshotExtension=Extent_Reports.getScreenshot(driver);
							Actions act = new Actions(driver); 
							
							//Click on TV provider link 
							objOptimum = Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
							act.moveToElement(objOptimum).click().build().perform();
							driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Provider Login page should display"+ Extent_Reports.logActual+"Provider login page is displayed");
							
							//Login screen validation
							String ParentWindow = driver.getWindowHandle();
							Set<String> s1=driver.getWindowHandles();
							Iterator<String> nWindow= s1.iterator();
							while(nWindow.hasNext()){
								String childWindow = nWindow.next();
								driver.switchTo().window(childWindow);
							}
							
							objOptLogin = Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
							if(objOptLogin.isDisplayed())
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Login page should display"+ Extent_Reports.logActual+"login page is displayed");
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Login page should display"+ Extent_Reports.logActual+"login page is not displayed");
							}
							
							//Enter User Name and Password details
							objUserName = Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
							objUserName.sendKeys(lstTestData.get(1));
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Enter user name"+ Extent_Reports.logActual+"User Name is entered as "+lstTestData.get(1));
							
							objPassword = Utilities.returnElement(driver,lstObject.get(14),lstObject.get(13));
							objPassword.sendKeys(lstTestData.get(2));
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Enter Password"+ Extent_Reports.logActual+"Password is entered as "+lstTestData.get(2));
							
							objlogin = Utilities.returnElement(driver,lstObject.get(17),lstObject.get(16));
							objlogin.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Submit button should be clicked"+ Extent_Reports.logActual+"Submit button is clicked");
							
							driver.switchTo().window(ParentWindow);
							
							objoptlogo = Utilities.returnElement(driver,lstObject.get(17),lstObject.get(16));
							if(objoptlogo.isDisplayed())
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"mvpd logo should display"+ Extent_Reports.logActual+"mvpd logo is displayed");
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"mvpd logo should display"+ Extent_Reports.logActual+"mvpd logo is not displayed");
							}
							
							
						 }
						 catch(Exception exc)
						 {
							 System.out.println(exc.getMessage());
						 }
						
						driver.close(); 
						
						return null;
					}		
		

		
	
}
