package com.nbcd.Pages;

//===============================================PACKAGES==========================================================================
import com.relevantcodes.extentreports.LogStatus;
import java.net.MalformedURLException;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Utilities;

//==============================================================CLASSES AND METHODS==================================================
public class PGShowHomePage_043VerifyFaceBookTags extends GetWebDriverInstance
{

//=========================================Variables=================================================================================
	static WebDriver driver;
	String sql;
	protected static String showDetails,screenshotExtension;
	DatabaseFunction db = new DatabaseFunction();
	public List<String> lstObject,lstTestData;
	String sqlQry,Status;
	WebElement android_package,android_app_name,android_url,ios_app_store_id,ios_app_name,ios_url,web_url,web_should_fallback;
	WebElement fb_app_id,og_site_name,og_title,og_type,og_url,og_description,og_image,og_image_type,og_image_width,og_image_height,FaceBookUname,FaceBookUpass,FaceBookbutton,ShowPageUrl,FETCH_NEW_SCRAPE;
	
//=================================================================================================================================================================================	
//Constructor to initialize all the Page Objects  
	public PGShowHomePage_043VerifyFaceBookTags(String Browser) throws Exception 
	{      
		try 
			{
				
				PGShowHomePage_043VerifyFaceBookTags.driver = GetWebDriverInstance.getBrowser(Browser);
				lstTestData=db.getTestDataObject("Select * from VerifyFBTags","Input");
				lstObject=db.getTestDataObject("Select * from VerifyFBTags","ObjectRepository");
					
			} 
			catch (MalformedURLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
					
					
		}
//========================================================================BUSINESS VALIDATION LOGIC=================================================
	@Test
		  public PGShowHomePage_043VerifyFaceBookTags VerifyFBTags( ) throws InterruptedException, FilloException 
		  {
				
			//Launching Browser with valid URL.
			     driver.get(lstTestData.get(0));
			     try {
						screenshotExtension=Extent_Reports.getScreenshot(PGShowHomePage_043VerifyFaceBookTags.driver);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			//Reading Objects
			try
			 {
				android_package =Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
				android_app_name=Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
				android_url=Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
				ios_app_store_id=Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
				ios_app_name=Utilities.returnElement(driver,lstObject.get(14),lstObject.get(13));
				ios_url=Utilities.returnElement(driver,lstObject.get(17),lstObject.get(16));
				web_url=Utilities.returnElement(driver,lstObject.get(20),lstObject.get(19));
				web_should_fallback=Utilities.returnElement(driver,lstObject.get(23),lstObject.get(22));
									
			/**android_package*/
				
				if (lstTestData.get(1).equalsIgnoreCase(android_package.getAttribute("content")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(1) +"':"+lstTestData.get(1) +Extent_Reports.logActual+lstObject.get(1) +"':"+android_package.getAttribute("content"));
					
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(1) +"':"+lstTestData.get(1) +Extent_Reports.logActual+lstObject.get(1) +"':"+android_package.getAttribute("content"));

				}
			/**android_app_name*/	
				if (lstTestData.get(2).equalsIgnoreCase(android_app_name.getAttribute("content")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(4) +"':"+lstTestData.get(2) +Extent_Reports.logActual+lstObject.get(4) +"':"+android_app_name.getAttribute("content"));
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(4) +"':"+lstTestData.get(2) + Extent_Reports.logActual+lstObject.get(4) +"':"+android_app_name.getAttribute("content"));

				}
				
			/**android_url*/
				if (lstTestData.get(3).equalsIgnoreCase(android_url.getAttribute("content")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(7) +"':"+lstTestData.get(3) +Extent_Reports.logActual+lstObject.get(7) +"':"+android_url.getAttribute("content"));
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(7) +"':"+lstTestData.get(3) +Extent_Reports.logActual+lstObject.get(7) +"':"+android_url.getAttribute("content"));

				}
				
			/** ios_app_store_id */
				if (lstTestData.get(4).equalsIgnoreCase(ios_app_store_id.getAttribute("content")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(10) +"':"+lstTestData.get(4) +Extent_Reports.logActual+lstObject.get(10) +"':"+ios_app_store_id.getAttribute("content"));
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(10) +"':"+lstTestData.get(4) +Extent_Reports.logActual+lstObject.get(10) +"':"+ios_app_store_id.getAttribute("content"));

				}
				/**ios_app_name*/
				if (lstTestData.get(5).equalsIgnoreCase(ios_app_name.getAttribute("content")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(13) +"':"+lstTestData.get(5) +Extent_Reports.logActual+lstObject.get(13) +"':"+ios_app_name.getAttribute("content"));

				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(13) +"':"+lstTestData.get(5) +Extent_Reports.logActual+lstObject.get(13) +"':"+ios_app_name.getAttribute("content"));

				}
				
				/** ios_url */
				if (lstTestData.get(6).equalsIgnoreCase(ios_url.getAttribute("content")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(16) +"':"+lstTestData.get(6) +Extent_Reports.logActual+lstObject.get(16) +"':"+ios_url.getAttribute("content"));
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(16) +"':"+lstTestData.get(6) +Extent_Reports.logActual+lstObject.get(16) +"':"+ios_url.getAttribute("content"));

				}
				
				/** web_url*/
				if (lstTestData.get(7).equalsIgnoreCase(web_url.getAttribute("content")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(19) +"':"+lstTestData.get(7) +Extent_Reports.logActual+lstObject.get(19) +"':"+web_url.getAttribute("content"));
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(19) +"':"+lstTestData.get(7) +Extent_Reports.logActual+lstObject.get(19) +"':"+web_url.getAttribute("content"));

				}
				
				/** web_should_fallback  */
				if (lstTestData.get(8).equalsIgnoreCase(web_should_fallback.getAttribute("content")))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(22) +"':"+lstTestData.get(8) +Extent_Reports.logActual+lstObject.get(22) +"':"+web_should_fallback.getAttribute("content"));
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(22) +"':"+lstTestData.get(8) +Extent_Reports.logActual+lstObject.get(22) +"':"+web_should_fallback.getAttribute("content"));

				}
				
			 }
			
		  		
			 catch(Exception exc)
			 {
				 System.out.println(exc.getMessage());
			 }
			
            driver.close(); 
			
			return null;

		  }
			//========================================================================BUSINESS VALIDATION LOGIC=================================================
	
				@Test
				  public PGShowHomePage_043VerifyFaceBookTags VerifymetaTags( ) throws InterruptedException, FilloException 
				  {
						
					//Launching Browser with valid URL.
					     driver.get(lstTestData.get(0));
					     Actions act = new Actions(driver);
					     try {
								screenshotExtension=Extent_Reports.getScreenshot(driver);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					//Reading Objects
					try
					 {
						fb_app_id =Utilities.returnElement(driver,lstObject.get(26),lstObject.get(25));
						og_site_name=Utilities.returnElement(driver,lstObject.get(29),lstObject.get(28));
						og_title=Utilities.returnElement(driver,lstObject.get(32),lstObject.get(31));
						og_type=Utilities.returnElement(driver,lstObject.get(35),lstObject.get(34));
						og_url=Utilities.returnElement(driver,lstObject.get(38),lstObject.get(37));
						og_description=Utilities.returnElement(driver,lstObject.get(41),lstObject.get(40));
						og_image=Utilities.returnElement(driver,lstObject.get(44),lstObject.get(43));
						og_image_type=Utilities.returnElement(driver,lstObject.get(47),lstObject.get(46));
						og_image_width=Utilities.returnElement(driver,lstObject.get(50),lstObject.get(49));
						og_image_height=Utilities.returnElement(driver,lstObject.get(53),lstObject.get(52));
						
																	
					/**fb_app_id*/
						
						if (lstTestData.get(9).equalsIgnoreCase(fb_app_id.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(25) +"':"+lstTestData.get(9) +Extent_Reports.logActual+lstObject.get(25) +"':"+fb_app_id.getAttribute("content"));
							
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(25) +"':"+lstTestData.get(9) +Extent_Reports.logActual+lstObject.get(25) +"':"+fb_app_id.getAttribute("content"));

						}
					/**og_site_name*/	
						if (lstTestData.get(10).equalsIgnoreCase(og_site_name.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(28) +"':"+lstTestData.get(10) +Extent_Reports.logActual+lstObject.get(28) +"':"+og_site_name.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(28) +"':"+lstTestData.get(10) + Extent_Reports.logActual+lstObject.get(28) +"':"+og_site_name.getAttribute("content"));

						}
						
					/**og_title*/
						if (lstTestData.get(11).equalsIgnoreCase(og_title.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(31) +"':"+lstTestData.get(11) +Extent_Reports.logActual+lstObject.get(31) +"':"+og_title.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(31) +"':"+lstTestData.get(11) +Extent_Reports.logActual+lstObject.get(31) +"':"+og_title.getAttribute("content"));

						}
						
					/** og_type */
						if (lstTestData.get(12).equalsIgnoreCase(og_type.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(34) +"':"+lstTestData.get(12) +Extent_Reports.logActual+lstObject.get(34) +"':"+og_type.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(34) +"':"+lstTestData.get(12) +Extent_Reports.logActual+lstObject.get(34) +"':"+og_type.getAttribute("content"));

						}
						/**og_url*/
						if (lstTestData.get(13).contentEquals(og_url.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(37) +"':"+lstTestData.get(13) +Extent_Reports.logActual+lstObject.get(37) +"':"+og_url.getAttribute("content"));

						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(37) +"':"+lstTestData.get(13) +Extent_Reports.logActual+lstObject.get(37) +"':"+og_url.getAttribute("content"));

						}
						
						/** og_description */
						if (lstTestData.get(14).contentEquals(og_description.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(40) +"':"+lstTestData.get(14) +Extent_Reports.logActual+lstObject.get(40) +"':"+og_description.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(40) +"':"+lstTestData.get(14) +Extent_Reports.logActual+lstObject.get(40) +"':"+og_description.getAttribute("content"));

						}
						
						/** og_image*/
						if (lstTestData.get(15).equalsIgnoreCase(og_image.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(43) +"':"+lstTestData.get(15) +Extent_Reports.logActual+lstObject.get(43) +"':"+og_image.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(43) +"':"+lstTestData.get(15) +Extent_Reports.logActual+lstObject.get(43) +"':"+og_image.getAttribute("content"));

						}
						
						/** og_image_type  */
						if (lstTestData.get(16).equalsIgnoreCase(og_image_type.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(46) +"':"+lstTestData.get(16) +Extent_Reports.logActual+lstObject.get(46) +"':"+og_image_type.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(46) +"':"+lstTestData.get(16) +Extent_Reports.logActual+lstObject.get(46) +"':"+og_image_type.getAttribute("content"));

						}
						
						/** og_image_width  */
						if (lstTestData.get(17).equalsIgnoreCase(og_image_width.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(49) +"':"+lstTestData.get(17) +Extent_Reports.logActual+lstObject.get(49) +"':"+og_image_width.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(49) +"':"+lstTestData.get(17) +Extent_Reports.logActual+lstObject.get(49) +"':"+og_image_width.getAttribute("content"));

						}

						/** og_image_height  */
						if (lstTestData.get(18).equalsIgnoreCase(og_image_height.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(52) +"':"+lstTestData.get(18) +Extent_Reports.logActual+lstObject.get(52) +"':"+og_image_height.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(52) +"':"+lstTestData.get(18) +Extent_Reports.logActual+lstObject.get(52) +"':"+og_image_height.getAttribute("content"));

						}
						
						driver.navigate().to(lstTestData.get(19));
						screenshotExtension=Extent_Reports.getScreenshot(driver);
						
						FaceBookUname=Utilities.returnElement(driver,lstObject.get(56),lstObject.get(55));
						FaceBookUname.sendKeys(lstTestData.get(20));

						Extent_Reports.logger.log(LogStatus.PASS,"Expected: Enter UserName"+ Extent_Reports.logExpected+lstObject.get(55));

						FaceBookUpass=Utilities.returnElement(driver,lstObject.get(59),lstObject.get(58));
						act.moveToElement(FaceBookUpass).build().perform();
						FaceBookUname.sendKeys(lstTestData.get(21));
						Extent_Reports.logger.log(LogStatus.PASS,"Expected: Enter Password"+ Extent_Reports.logExpected+lstObject.get(58));

						FaceBookbutton=Utilities.returnElement(driver,lstObject.get(62),lstObject.get(61));
						act.moveToElement(FaceBookUname).click().build().perform();
						Extent_Reports.logger.log(LogStatus.PASS,"Expected: Click on Log in Button"+ Extent_Reports.logExpected+lstObject.get(61));

						ShowPageUrl=Utilities.returnElement(driver,lstObject.get(56),lstObject.get(55));
						act.moveToElement(ShowPageUrl).build().perform();
						ShowPageUrl.sendKeys(lstTestData.get(22));
						Extent_Reports.logger.log(LogStatus.PASS,"Enter the show home page url in input url field"+ Extent_Reports.logExpected+lstObject.get(61));
						
						FETCH_NEW_SCRAPE=Utilities.returnElement(driver,lstObject.get(59),lstObject.get(58));
						act.moveToElement(FETCH_NEW_SCRAPE).click().build().perform();
						Extent_Reports.logger.log(LogStatus.PASS,"Click on the Fetch NEW SCRAPE INFORMATION"+ Extent_Reports.logExpected+lstObject.get(61));
						
                        /**fb_app_id*/
						
						if (lstTestData.get(9).equalsIgnoreCase(fb_app_id.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(25) +"':"+lstTestData.get(9) +Extent_Reports.logActual+lstObject.get(25) +"':"+fb_app_id.getAttribute("content"));
							
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(25) +"':"+lstTestData.get(9) +Extent_Reports.logActual+lstObject.get(25) +"':"+fb_app_id.getAttribute("content"));

						}
					/**og_site_name*/	
						if (lstTestData.get(10).equalsIgnoreCase(og_site_name.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(28) +"':"+lstTestData.get(10) +Extent_Reports.logActual+lstObject.get(28) +"':"+og_site_name.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(28) +"':"+lstTestData.get(10) + Extent_Reports.logActual+lstObject.get(28) +"':"+og_site_name.getAttribute("content"));

						}
						
					/**og_title*/
						if (lstTestData.get(11).equalsIgnoreCase(og_title.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(31) +"':"+lstTestData.get(11) +Extent_Reports.logActual+lstObject.get(31) +"':"+og_title.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(31) +"':"+lstTestData.get(11) +Extent_Reports.logActual+lstObject.get(31) +"':"+og_title.getAttribute("content"));

						}
						
					/** og_type */
						if (lstTestData.get(12).equalsIgnoreCase(og_type.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(34) +"':"+lstTestData.get(12) +Extent_Reports.logActual+lstObject.get(34) +"':"+og_type.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(34) +"':"+lstTestData.get(12) +Extent_Reports.logActual+lstObject.get(34) +"':"+og_type.getAttribute("content"));

						}
						/**og_url*/
						if (lstTestData.get(13).equalsIgnoreCase(og_url.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(37) +"':"+lstTestData.get(13) +Extent_Reports.logActual+lstObject.get(37) +"':"+og_url.getAttribute("content"));

						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(37) +"':"+lstTestData.get(13) +Extent_Reports.logActual+lstObject.get(37) +"':"+og_url.getAttribute("content"));

						}
						
						/** og_description */
						if (lstTestData.get(14).equalsIgnoreCase(og_description.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(40) +"':"+lstTestData.get(14) +Extent_Reports.logActual+lstObject.get(40) +"':"+og_description.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(40) +"':"+lstTestData.get(14) +Extent_Reports.logActual+lstObject.get(40) +"':"+og_description.getAttribute("content"));

						}
						
						/** og_image*/
						if (lstTestData.get(15).equalsIgnoreCase(og_image.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(43) +"':"+lstTestData.get(15) +Extent_Reports.logActual+lstObject.get(43) +"':"+og_image.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(43) +"':"+lstTestData.get(15) +Extent_Reports.logActual+lstObject.get(43) +"':"+og_image.getAttribute("content"));

						}
						
						/** og_image_type  */
						if (lstTestData.get(16).equalsIgnoreCase(og_image_type.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(46) +"':"+lstTestData.get(16) +Extent_Reports.logActual+lstObject.get(46) +"':"+og_image_type.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(46) +"':"+lstTestData.get(16) +Extent_Reports.logActual+lstObject.get(46) +"':"+og_image_type.getAttribute("content"));

						}
						
						/** og_image_width  */
						if (lstTestData.get(17).equalsIgnoreCase(og_image_width.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(49) +"':"+lstTestData.get(17) +Extent_Reports.logActual+lstObject.get(49) +"':"+og_image_width.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(49) +"':"+lstTestData.get(17) +Extent_Reports.logActual+lstObject.get(49) +"':"+og_image_width.getAttribute("content"));

						}

						/** og_image_height  */
						if (lstTestData.get(18).equalsIgnoreCase(og_image_height.getAttribute("content")))
						{
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+lstObject.get(52) +"':"+lstTestData.get(18) +Extent_Reports.logActual+lstObject.get(52) +"':"+og_image_height.getAttribute("content"));
						}
						else
						{
							Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+lstObject.get(52) +"':"+lstTestData.get(18) +Extent_Reports.logActual+lstObject.get(52) +"':"+og_image_height.getAttribute("content"));

						}

					 }
					
					
					 catch(Exception exc)
					 {
						 System.out.println(exc.getMessage());
					 }
							
		//	driver.close(); 
			
			return null;
		}
				
	
	  
}
