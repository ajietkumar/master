package com.nbcd.Pages;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Utilities;
import com.relevantcodes.extentreports.LogStatus;

public class PGAppsLandingPage {

	private static final String VerifyAppsLandingPage = null;
		//=========================================Variables=================================================================================
		private static WebDriver driver;
		String sql;
		protected static String showDetails;
		DatabaseFunction db = new DatabaseFunction();
		public List<String> lstObject,lstTestData;
		static String screenshotExtension;
		String sqlQry,Status,strResultText;
		WebElement objAppLink,objAndroidAppImg,objRokuChannelImg,objXboxOneAppImg,objShowMenuItem,objEpisodeItem,objSCHEDULEItem,objNEWSSPORTSItem;
		WebElement objSHOPItem,objAPPItem,objLIVEItem,objAppIntro,objiOSAppDowload,objiOSAppImage,objiOSApplogo;
		WebElement objAppleTVImage,AppleTVAppDowload,objAppleTVApplogo,objAmazonFireTVImage,objAmazonFireTVImageURLDowload,objAmazonFireTVlogo;
		WebElement objAppPageFooter,objAndroidAppImage,objAndroidApplogo,objAndroidAppDowload;
		
	//=================================================================================================================================================================================	
	//Constructor to initialize all the Page Objects  
		public PGAppsLandingPage(String Browser) 
		{      
			try 
				{
					
					this.driver = GetWebDriverInstance.getBrowser(Browser);
					lstTestData=db.getTestDataObject("Select * from AppsLandingPage","Input");
					lstObject=db.getTestDataObject("Select * from AppsLandingPage","ObjectRepository");
				} 
				catch (MalformedURLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
						
						
			}
	//========================================================================BUSINESS VALIDATION LOGIC=================================================
		@Test
		  public PGAppsLandingPage VerifyAppsLandingPage( ) throws InterruptedException, FilloException 
		  {
			
				//Launching Browser with valid URL.
				     driver.get(lstTestData.get(0));
				     try
				     {
				     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Browser should Launch"+Extent_Reports.logActual+"Browser Launch is succesfull");
				     screenshotExtension=Extent_Reports.getScreenshot(driver);
				     }
				     catch(Exception exc)
					 {
						 System.out.println(exc.getMessage());
					 }
					
				//Reading Objects
				try
				 {
					driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
					WebElement objAppLink =Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(6);
					objAppLink.click();
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Apps Landing Page should display"+ Extent_Reports.logActual+"Apps Landing page is dispalyed after App link is clicked from global navigation");
					screenshotExtension=Extent_Reports.getScreenshot(driver);
					
					WebElement objShowMenuItem =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(1);
					if(objShowMenuItem.isDisplayed()) 
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: Shows should display"+ Extent_Reports.logActual+"Menu Items: Shows is dispalyed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: Shows should display"+ Extent_Reports.logActual+"Menu Items: Shows is not dispalyed");
					}
					WebElement objEpisodeItem =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(2);
					if(objEpisodeItem.isDisplayed()) 
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: Episode should display"+ Extent_Reports.logActual+"Menu Items: Episode is dispalyed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: Episode should display"+ Extent_Reports.logActual+"Menu Items: Episode is not dispalyed");
					}
					
					WebElement objSCHEDULEItem =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(3);
					if(objSCHEDULEItem.isDisplayed())  
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: SCHEDULE should display"+ Extent_Reports.logActual+"Menu Items: SCHEDULE is dispalyed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: SCHEDULE should display"+ Extent_Reports.logActual+"Menu Items: SCHEDULE is not dispalyed");
					}
					WebElement objNEWSSPORTSItem =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(4);
					if(objNEWSSPORTSItem.isDisplayed())
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: NEWS & SPORTS should display"+ Extent_Reports.logActual+"Menu Items: NEWS & SPORTS is dispalyed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: NEWS & SPORTS should display"+ Extent_Reports.logActual+"Menu Items: NEWS & SPORTS is not dispalyed");
					}
					
					WebElement objSHOPItem =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(5);
					if(objSHOPItem.isDisplayed()) 
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: SHOP should display"+ Extent_Reports.logActual+"Menu Items: SHOP is dispalyed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: SHOP should display"+ Extent_Reports.logActual+"Menu Items: SHOP is not dispalyed");
					}
					
					WebElement objAPPItem =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(6);
					if(objAPPItem.isDisplayed())  
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: APP should display"+ Extent_Reports.logActual+"Menu Items: APP is dispalyed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: APP should display"+ Extent_Reports.logActual+"Menu Items: APP is not dispalyed");
					}
					
					WebElement objLIVEItem =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(7);
					if(objLIVEItem.isDisplayed())  
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: LIVE should display"+ Extent_Reports.logActual+"Menu Items: LIVE is dispalyed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: LIVE should display"+ Extent_Reports.logActual+"Menu Items: LIVE is not dispalyed");
					}
					screenshotExtension=Extent_Reports.getScreenshot(driver);
					
					objAppIntro =Utilities.returnElement(driver,lstObject.get(17),lstObject.get(16));
					String valAppPageIntro = objAppIntro.getText();
					System.out.println(valAppPageIntro);
					if(valAppPageIntro.contentEquals(lstTestData.get(1))) 
					
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"App Page Intro should display"+ Extent_Reports.logActual+"App Page Intro  is dispalyed and the text is "+valAppPageIntro);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"App Page Intro should display"+ Extent_Reports.logActual+"App Page Intro  is not dispalyed as expected and the text is "+valAppPageIntro);
					}
					screenshotExtension=Extent_Reports.getScreenshot(driver);
					//ios
					WebElement objiOSAppImage =Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(0);
					String iOSAppImageURL = objiOSAppImage.getAttribute("href");
					if(iOSAppImageURL.equalsIgnoreCase(lstTestData.get(2)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"iOSApp image link should match"+ Extent_Reports.logActual+"iOSApp image link should matching with expected and the link is: "+iOSAppImageURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"iOSApp image link should match"+ Extent_Reports.logActual+"iOSApp image link should not matching with expected and the link is: "+iOSAppImageURL);
					}
					
					
					WebElement objiOSAppDowload =Utilities.returnElements(driver,lstObject.get(23),lstObject.get(22)).get(0);
					String iOSAppDowloadURL = objiOSAppDowload.getAttribute("href");
					System.out.println(iOSAppDowloadURL);
					if(iOSAppDowloadURL.equalsIgnoreCase(lstTestData.get(3)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"iOSApp Download link should match"+ Extent_Reports.logActual+"iOSApp Download link should matching with expected and the link is: "+iOSAppDowloadURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"iOSApp Download link should match"+ Extent_Reports.logActual+"iOSApp Download link should not matching with expected and the link is: "+iOSAppDowloadURL);
					}
					
					WebElement objiOSApplogo =Utilities.returnElements(driver,lstObject.get(26),lstObject.get(25)).get(0);
					String iOSApplogoURL = objiOSApplogo.getAttribute("href");
					if(iOSApplogoURL.equalsIgnoreCase(lstTestData.get(4)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"iOSApp logo link should match"+ Extent_Reports.logActual+"iOSApp logo link should matching with expected and the link is: "+iOSApplogoURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"iOSApp logo link should match"+ Extent_Reports.logActual+"iOSApp logo link should not matching with expected and the link is: "+iOSApplogoURL);
					}
					
					//AndroidAppa
					WebElement objAndroidAppImage =Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(1);
					String AndroidAppImageURL = objAndroidAppImage.getAttribute("href");
					if(AndroidAppImageURL.equalsIgnoreCase(lstTestData.get(5)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"AndroidApp image link should match"+ Extent_Reports.logActual+"AndroidApp image link should matching with expected and the link is: "+AndroidAppImageURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"AndroidApp image link should match"+ Extent_Reports.logActual+"AndroidApp image link should not matching with expected and the link is: "+iOSAppImageURL);
					}
					
					
					WebElement objAndroidAppDowload =Utilities.returnElements(driver,lstObject.get(23),lstObject.get(22)).get(1);
					String AndroidAppDowloadURL = objAndroidAppDowload.getAttribute("href");
					System.out.println(AndroidAppDowloadURL);
					if(AndroidAppDowloadURL.equalsIgnoreCase(lstTestData.get(6)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"AndroidApp Download link should match"+ Extent_Reports.logActual+"AndroidApp Download link should matching with expected and the link is: "+AndroidAppDowloadURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"AndroidApp Download link should match"+ Extent_Reports.logActual+"AndroidApp Download link should not matching with expected and the link is: "+AndroidAppDowloadURL);
					}
					
					WebElement objAndroidApplogo =Utilities.returnElements(driver,lstObject.get(26),lstObject.get(25)).get(1);
					String AndroidApplogoURL = objAndroidApplogo.getAttribute("href");
					if(AndroidApplogoURL.equalsIgnoreCase(lstTestData.get(7)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"AndroidApp logo link should match"+ Extent_Reports.logActual+"AndroidApp logo link should matching with expected and the link is: "+AndroidApplogoURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"AndroidApp logo link should match"+ Extent_Reports.logActual+"AndroidApp logo link should not matching with expected and the link is: "+AndroidApplogoURL);
					}
					
					//AppleTV
					WebElement objAppleTVImage =Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(4);
					String AppleTvImageURL = objAppleTVImage.getAttribute("href");
					if(AppleTvImageURL.equalsIgnoreCase(lstTestData.get(2)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Apple TV image link should match"+ Extent_Reports.logActual+"Apple TV image link should matching with expected and the link is: "+AppleTvImageURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Apple TV image link should match"+ Extent_Reports.logActual+"Apple TV image link should not matching with expected and the link is: "+AppleTvImageURL);
					}
					
					
					WebElement AppleTVAppDowload =Utilities.returnElements(driver,lstObject.get(23),lstObject.get(22)).get(4);
					String AppleTVDowloadURL = AppleTVAppDowload.getAttribute("href");
					System.out.println(AppleTVDowloadURL);
					if(AppleTVDowloadURL.equalsIgnoreCase(lstTestData.get(3)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Apple TV Download link should match"+ Extent_Reports.logActual+"Apple TV Download link should matching with expected and the link is: "+AppleTVDowloadURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Apple TV Download link should match"+ Extent_Reports.logActual+"Apple TV Download link should not matching with expected and the link is: "+AppleTVDowloadURL);
					}
					
					WebElement objAppleTVApplogo =Utilities.returnElements(driver,lstObject.get(26),lstObject.get(25)).get(4);
					String ApplieTVlogoURL = objAppleTVApplogo.getAttribute("href");
					if(ApplieTVlogoURL.equalsIgnoreCase(lstTestData.get(4)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"AmazonFireTV logo link should match"+ Extent_Reports.logActual+"iOSApp logo link should matching with expected and the link is: "+iOSApplogoURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"AmazonFireTV logo link should match"+ Extent_Reports.logActual+"iOSApp logo link should not matching with expected and the link is: "+iOSApplogoURL);
					}
					
					//AmazonFire
					WebElement objAmazonFireTVImage =Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(3);
					String AmazonFireTVImageURL = objAmazonFireTVImage.getAttribute("href");
					if(AmazonFireTVImageURL.equalsIgnoreCase(lstTestData.get(2)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"AmazonFireTV image link should match"+ Extent_Reports.logActual+"AmazonFireTV image link should matching with expected and the link is: "+AmazonFireTVImageURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"AmazonFireTV image link should match"+ Extent_Reports.logActual+"AmazonFireTV image link should not matching with expected and the link is: "+AmazonFireTVImageURL);
					}
					
					
					WebElement objAmazonFireTVImageURLDowload =Utilities.returnElements(driver,lstObject.get(23),lstObject.get(22)).get(3);
					String AmazonFireTVImageURLDowloadURL = objAmazonFireTVImageURLDowload.getAttribute("href");
					System.out.println(AmazonFireTVImageURLDowloadURL);
					if(AmazonFireTVImageURLDowloadURL.equalsIgnoreCase(lstTestData.get(3)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"AmazonFireTV Download link should match"+ Extent_Reports.logActual+"AmazonFireTV Download link should matching with expected and the link is: "+AmazonFireTVImageURLDowloadURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"AmazonFireTV Download link should match"+ Extent_Reports.logActual+"AmazonFireTV Download link should not matching with expected and the link is: "+AmazonFireTVImageURLDowloadURL);
					}
					
					WebElement objAmazonFireTVlogo =Utilities.returnElements(driver,lstObject.get(26),lstObject.get(25)).get(3);
					String AmazonFireTVlogoURL = objAmazonFireTVlogo.getAttribute("href");
					if(AmazonFireTVlogoURL.equalsIgnoreCase(lstTestData.get(4)))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"AmazonFireTV logo link should match"+ Extent_Reports.logActual+"AmazonFireTV logo link should matching with expected and the link is: "+AmazonFireTVlogoURL);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"AmazonFireTV logo link should match"+ Extent_Reports.logActual+"AmazonFireTV logo link should not matching with expected and the link is: "+AmazonFireTVlogoURL);
					}
					
					//Image validation
					objAndroidAppImg = Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
					if(objAndroidAppImg.isDisplayed());  
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"AndroidApp image should display"+ Extent_Reports.logActual+"AndroidApp image is dispalyed");
					}
					
					objRokuChannelImg = Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
					if(objRokuChannelImg.isDisplayed());  
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Roku Channel image should display"+ Extent_Reports.logActual+"Roku Channel image is dispalyed");
					}
					
					objXboxOneAppImg = Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
					if(objXboxOneAppImg.isDisplayed());  
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Xbox One App  image should display"+ Extent_Reports.logActual+"Xbox One App  image is dispalyed");
					}
					
					//Footer validation
					objAppPageFooter =Utilities.returnElement(driver,lstObject.get(29),lstObject.get(28));
					if(objAppPageFooter.isDisplayed())
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Footer should display"+ Extent_Reports.logActual+"Footer is dispalyed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Footer should display"+ Extent_Reports.logActual+"Footer is not dispalyed");
					}
					
				 }
				 catch(Exception exc)
				 {
					 System.out.println(exc.getMessage());
				 }
				
				driver.close(); 
				
				return null;
			} 

}
		

