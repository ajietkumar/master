package com.nbcd.Pages;

import java.net.MalformedURLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Synchronization;
import com.nbcd.GenericLib.Utilities;
import com.relevantcodes.extentreports.LogStatus;

public class PGShowVideoDetailPage {

	private static final String VerifyAppsLandingPage = null;
		//=========================================Variables=================================================================================
		private static WebDriver driver;
		String sql;
		protected static String showDetails;
		DatabaseFunction db = new DatabaseFunction();
		public List<String> lstObject,lstTestData,arrSeasonsOptions;
		static String screenshotExtension;
		String sqlQry,Status,strResultText;
		WebElement objSeasonList;
		
	//=================================================================================================================================================================================	
	//Constructor to initialize all the Page Objects  
		public PGShowVideoDetailPage(String Browser) 
		{      
			try 
				{
					
					this.driver = GetWebDriverInstance.getBrowser(Browser);
					lstTestData=db.getTestDataObject("Select * from ShowVideoDetailPage","Input");
					lstObject=db.getTestDataObject("Select * from ShowVideoDetailPage","ObjectRepository");
				} 
				catch (MalformedURLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
						
						
			}
	//========================================================================BUSINESS VALIDATION LOGIC=================================================
		@Test
		  public PGShowVideoDetailPage VerifyVideoDetailPageOpened( ) throws InterruptedException, FilloException 
		  {
			
				//Launching Browser with valid URL.
				     driver.get(lstTestData.get(0));
					 
				     try
				     {
				     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
				     screenshotExtension=Extent_Reports.getScreenshot(driver);
				     }
				     catch(Exception exc)
					 {
						 System.out.println(exc.getMessage());
					 }
					
				//Reading Objects
				try
				 {
					
					driver.navigate().to(lstTestData.get(1));
					String VideoURL = driver.getCurrentUrl();
					if(VideoURL.contentEquals("https://www.nbc.com/video"))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Video Detail Page should display"+Extent_Reports.logActual+"Video Detail Page is displayed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Video Detail Page should display"+Extent_Reports.logActual+"Video Detail Page is not displayed");
					}
					
					driver.navigate().to(lstTestData.get(2));
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Navigate to different page"+Extent_Reports.logActual+"Navigated to different page");
					driver.navigate().to(lstTestData.get(1));
					String VideoURLs = driver.getCurrentUrl();
					if(VideoURLs.contentEquals("https://www.nbc.com/video"))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Video Detail Page should display"+Extent_Reports.logActual+"Video Detail Page is displayed");
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Video Detail Page should display"+Extent_Reports.logActual+"Video Detail Page is not displayed");
					}
					
					
				 }
				 catch(Exception exc)
				 {
					 System.out.println(exc.getMessage());
				 }
				
				//driver.close(); 
				
				return null;
			} 
	
//========================================================================Desktop-Verify order of Seasons in Episode drop down menu of Classic Show Video details page in Responsive Web Site in (DBB-3105)=================================================
		@Test
		  public PGShowVideoDetailPage VerifyVideosSeasonlistSorting( ) throws InterruptedException, FilloException 
		  {
			
				//Launching Browser with valid URL.
				     driver.get(lstTestData.get(0));
					 
				     try
				     {
				     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
				     screenshotExtension=Extent_Reports.getScreenshot(driver);
				     }
				     catch(Exception exc)
					 {
						 System.out.println(exc.getMessage());
					 }
					
				//Reading Objects
				try
				 {
					WebElement objShowLink = Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(0);
					objShowLink.click();
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Click on Shows"+Extent_Reports.logActual+"Shows Link is clicked from global navigation");
					WebElement objShowList = Utilities.returnElements(driver,lstObject.get(5),lstObject.get(4)).get(1);
					String ShowlistText = objShowList.getText();
					System.out.println(ShowlistText);
					objShowList.click();
					
					//Actions act = new Actions(driver);
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Click on any Show"+Extent_Reports.logActual+"Show is clicked from Shows list");
					System.out.println("lllllllll");
					//WebElement objVideo = Utilities.returnElements(driver,lstObject.get(8),lstObject.get(7)).get(1);
					//act.moveToElement(objVideo).click();
					//objVideo.click();
					//Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Video should be clicked"+Extent_Reports.logActual+"Video is clicked");
					//Actions act = new Actions(driver);
					Synchronization.implicitWait(driver, 50);
					System.out.println("kiujyyyyy");
					//driver.findElement(By.cssSelector("div.sticky-outer-wrapper.show-header.show-header--animate > div:nth-child(1 ) > div:nth-child(2) > ul > li:nth-child(4) a")).click();
					//driver.findElement(By.xpath("//*[@id='main']/section/div[2]//a[contains(text(),'Episodes')]")).click();
					driver.findElement(By.xpath("//section[@class='show-page']/div[2]/div/child::div[2]/ul/child::li[4]/a")).click();
					//*[@id="main"]/section/div[2]/div/div[2]
					//System.out.println(a.get(0).getText());
					System.out.println("kiuj");
					
					//WebElement objEpisode = Utilities.returnElements(driver,lstObject.get(11),lstObject.get(10)).get(1);
					//act.moveToElement(objEpisode).click();
					//objEpisode.wait(30);
					System.out.println("fffffff");
					//objEpisode.click();
					System.out.println("yyyyyyyyy");
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Episode tab should be clicked"+Extent_Reports.logActual+"Episode tab is clicked");
					objSeasonList = Utilities.returnElement(driver,lstObject.get(14),lstObject.get(13));
					System.out.println("lokiolkioioipppp");
					
					
				 }
				 catch(Exception exc)
				 {
					 System.out.println(exc.getMessage());
				 }
				
				//driver.close(); 
				
				return null;
			} 
			
		//========================================================================Desktop-Verify meta tag =================================================
				@Test
				  public PGShowVideoDetailPage VerifyMetatagsmartlink ( ) throws InterruptedException, FilloException 
				  {
					
						//Launching Browser with valid URL.
						     driver.get(lstTestData.get(0));
							 
						     try
						     {
						     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
						     screenshotExtension=Extent_Reports.getScreenshot(driver);
						     }
						     catch(Exception exc)
							 {
								 System.out.println(exc.getMessage());
							 }
							
						//Reading Objects
						try
						 {
							WebElement objShowLink = Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(0);
							objShowLink.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Click on Shows"+Extent_Reports.logActual+"Shows Link is clicked from global navigation");
							WebElement objShowList = Utilities.returnElements(driver,lstObject.get(5),lstObject.get(4)).get(1);
							String ShowlistText = objShowList.getText();
							System.out.println(ShowlistText);
							objShowList.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Click on Shows"+Extent_Reports.logActual+"Shows Link is clicked from global navigation and the show is "+ShowlistText);
							Synchronization.implicitWait(driver, 160);
							List <WebElement> h = driver.findElements(By.cssSelector("div.video-list__container > div > a"));
							 System.out.println(h.get(0).getText());
							 System.out.println(h.get(1).getText());
							 h.get(0).click();
							 Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Click on Show Video"+Extent_Reports.logActual+"Show video is clicked ");
							String txt = driver.findElement(By.cssSelector("img.video__smart-link")).getAttribute("src");
							System.out.println(txt);
							if(txt.contentEquals("https://smart.link/58b4a4186ac97"))
							{
								 Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Meta tag for smart link should be as expected"+Extent_Reports.logActual+"Meta tag for smart link is as expected and the tag is "+txt);
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Meta tag for smart link should be as expected"+Extent_Reports.logActual+"Meta tag for smart link is as not expected and the tag is "+txt);
							}
							
						 }
						 catch(Exception exc)
						 {
							 System.out.println(exc.getMessage());
						 }
						
						driver.close(); 
						
						return null;
					} 		
	
	//========================================================================Desktop-Verify meta tag =================================================
				@Test
				  public PGShowVideoDetailPage VerifySNLEpisode ( ) throws InterruptedException, FilloException 
				  {
					
						//Launching Browser with valid URL.
						     driver.get(lstTestData.get(0));
							 
						     try
						     {
						     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
						     screenshotExtension=Extent_Reports.getScreenshot(driver);
						     }
						     catch(Exception exc)
							 {
								 System.out.println(exc.getMessage());
							 }
							
						//Reading Objects
						try
						 {
							WebElement objShowLink = Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(0);
							objShowLink.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Click on Shows"+Extent_Reports.logActual+"Shows Link is clicked from global navigation");
							WebElement objShowList = Utilities.returnElements(driver,lstObject.get(5),lstObject.get(4)).get(15);
							String ShowlistText = objShowList.getText();
							System.out.println(ShowlistText);
							objShowList.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Click on Shows"+Extent_Reports.logActual+"Shows Link is clicked from global navigation and the show is "+ShowlistText);
							Synchronization.implicitWait(driver, 160);
							List <WebElement> h = driver.findElements(By.cssSelector("div.video-list__container > div > a"));
							 System.out.println(h.get(0).getText());
							 System.out.println(h.get(1).getText());
							 h.get(0).click();
							 System.out.println(driver.getTitle());
							 driver.navigate().back();
							 System.out.println(driver.getTitle());
							 String strSNLTitle = driver.getTitle();
							if(strSNLTitle.contentEquals(" Saturday Night Live - NBC.com"))
							{
								 Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"SNL page should display"+Extent_Reports.logActual+"SNL page is displayed ");
							}
							else
							{
								Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"SNL page should display"+Extent_Reports.logActual+"NL page is not displayed ");
							
							}
						 }
						 catch(Exception exc)
						 {
							 System.out.println(exc.getMessage());
						 }
						
						driver.close(); 
						
						return null;
					} 		
//========================================================================Desktop-Verify air date sort =================================================
				@Test
				  public PGShowVideoDetailPage VerifyEarliestairdatetolatestairdate ( ) throws InterruptedException, FilloException 
				  {
					
						//Launching Browser with valid URL.
						     driver.get(lstTestData.get(0));
							 
						     try
						     {
						     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"NBC Home Page should Launch"+Extent_Reports.logActual+"NBC Home page launched succesfull");
						     screenshotExtension=Extent_Reports.getScreenshot(driver);
						     }
						     catch(Exception exc)
							 {
								 System.out.println(exc.getMessage());
							 }
							
						//Reading Objects
						try
						 {
							WebElement objShowLink = Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(0);
							objShowLink.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Click on Shows"+Extent_Reports.logActual+"Shows Link is clicked from global navigation");
							WebElement objShowList = Utilities.returnElements(driver,lstObject.get(5),lstObject.get(4)).get(1);
							String ShowlistText = objShowList.getText();
							System.out.println(ShowlistText);
							objShowList.click();
							Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Click on Shows"+Extent_Reports.logActual+"Shows Link is clicked from global navigation and the show is "+ShowlistText);
							Synchronization.implicitWait(driver, 160);
							String compVal = null;
							List<WebElement> a =  driver.findElements(By.cssSelector("div.show-page__modules >section:nth-child(1) > div >div > div >a"));
							int b = a.size();
							System.out.println(b);
							for(int i =0;i<b;i++)
							{
								String c= a.get(i).getText();
								System.out.println(c);
								String[] lines = c.split("\\n");
								String line1 = lines[0];
								String line2 = lines[1];
								if(line1.contentEquals("NEW"))
								{
									System.out.println(line2);
									String actual=line2.substring(8,16);
									System.out.println(actual);
									compVal = actual+";"+compVal ;
									System.out.println(compVal);
								}
								else
								{
									System.out.println(line1);
									String actual=line1.substring(8,16);
									System.out.println(actual);
									compVal = actual+";"+compVal ;
									System.out.println(compVal);
								}
							}
							
							
						 }
						 catch(Exception exc)
						 {
							 System.out.println(exc.getMessage());
						 }
						
						//driver.close(); 
						
						return null;
					} 		
						
							
				
		
}