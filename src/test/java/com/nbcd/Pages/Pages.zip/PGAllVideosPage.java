package com.nbcd.Pages;

//===============================================PACKAGES==========================================================================
import com.relevantcodes.extentreports.LogStatus;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Synchronization;
import com.nbcd.GenericLib.Utilities;

//==============================================================CLASSES AND METHODS==================================================
public class PGAllVideosPage extends GetWebDriverInstance
{

//=========================================Variables=================================================================================
	static WebDriver driver;
	String sql;
	protected static String showDetails,screenshotExtension;
	DatabaseFunction db = new DatabaseFunction();
	public List<String> lstObject,lstTestData;
	String sqlQry,Status,Show_Name,Show_Title,Show_Date;
	boolean Livelink;
	WebElement objEpisodes,objepisode_Title,objepisode_Date,objshow_Name;
	List<WebElement> list;
	ArrayList<String> arr;
	ArrayList<Date> arr2;
	
//=================================================================================================================================================================================	
//Constructor to initialize all the Page Objects  
	public PGAllVideosPage(String Browser) throws Exception 
	{      
		try 
			{
				
				PGAllVideosPage.driver = GetWebDriverInstance.getBrowser(Browser);
				lstTestData=db.getTestDataObject("Select * from PGAllVideosPage","Input");
				lstObject=db.getTestDataObject("Select * from PGAllVideosPage","ObjectRepository");
				
			} 
			catch (MalformedURLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
					
					
		}
//=========================================== verify the page redirect rules for all All legacy Video URLs  (DBB-3761) =================================================
	@Test
		  public PGAllVideosPage Verify_Page_redirect( ) throws InterruptedException, FilloException 
		  {
				
			//Launching Browser with valid URL.
			     driver.get(lstTestData.get(0));
			     Synchronization.implicitWait(driver, 30);
			     try {
					//	screenshotExtension=Extent_Reports.getScreenshot(driver);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			//Reading Objects
			 
			 
			 
			try
			 {
								
				driver.navigate().to(lstTestData.get(1));
				Synchronization.implicitWait(driver, 30);
			//	screenshotExtension=Extent_Reports.getScreenshot(driver);
				String Full_episodes_url= driver.getCurrentUrl();
				System.out.println("********full-episodes**********");
				driver.navigate().back();
				Synchronization.implicitWait(driver, 30);
                /**full-episodes*/
		/*		
				if (lstTestData.get(1).contentEquals(Full_episodes_url))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + lstTestData.get(1)+ "full-episodes  URL should be redirect to :"+ lstTestData.get(1) +Extent_Reports.logActual + "Actual redirected URL is :"+ Full_episodes_url );
				}	
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + lstTestData.get(1)+ "full-episodes  URL should be redirect to :"+ lstTestData.get(1) +Extent_Reports.logActual + "Actual redirected URL is :"+ Full_episodes_url);

				}
		*/		
				driver.navigate().to(lstTestData.get(2));
				Synchronization.implicitWait(driver, 30);
			//	screenshotExtension=Extent_Reports.getScreenshot(driver);
				String clips_url= driver.getCurrentUrl();
				System.out.println(clips_url);
				driver.navigate().back();
				Synchronization.implicitWait(driver, 30);

				/**clips*/
		/*		
				if (lstTestData.get(2).contentEquals(clips_url))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + lstTestData.get(2)+ "clips URL should be redirect to :"+ lstTestData.get(2) +Extent_Reports.logActual + "Actual redirected URL is :"+ clips_url );
				}	
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + lstTestData.get(2)+ "clips  URL should be redirect to :"+ lstTestData.get(2) +Extent_Reports.logActual + "Actual redirected URL is :"+ clips_url);

				}
		*/
				driver.navigate().to(lstTestData.get(3));
				Synchronization.implicitWait(driver, 30);
		//		screenshotExtension=Extent_Reports.getScreenshot(driver);
				String popular_url= driver.getCurrentUrl();
				System.out.println(popular_url);
				driver.navigate().back();
				Synchronization.implicitWait(driver, 30);

				/**popular*/
		/*		
				if (lstTestData.get(3).contentEquals(clips_url))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + lstTestData.get(3)+ "popular URL should be redirect to :"+ lstTestData.get(3) +Extent_Reports.logActual + "Actual redirected URL is :"+ popular_url );
				}	
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + lstTestData.get(3)+ "popular URL should be redirect to :"+ lstTestData.get(3) +Extent_Reports.logActual + "Actual redirected URL is :"+ popular_url);

				}

		*/
				driver.navigate().to(lstTestData.get(4));
				Synchronization.implicitWait(driver, 30);
				String classics_url = driver.getCurrentUrl();
	//			screenshotExtension=Extent_Reports.getScreenshot(driver);
				System.out.println(classics_url);
				driver.navigate().back();
				Synchronization.implicitWait(driver, 30);

				/**classics*/
	/*			
				if (lstTestData.get(4).contentEquals(classics_url))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + lstTestData.get(4)+ "classics URL should be redirect to :"+ lstTestData.get(4) +Extent_Reports.logActual + "Actual redirected URL is :"+ classics_url );
				}	
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + lstTestData.get(4)+ "classics URL should be redirect to :"+ lstTestData.get(4) +Extent_Reports.logActual + "Actual redirected URL is :"+ classics_url);

				}
	*/			
				driver.navigate().to(lstTestData.get(5));
				Synchronization.implicitWait(driver, 30);
	//			screenshotExtension=Extent_Reports.getScreenshot(driver);
				String video_url= driver.getCurrentUrl();
				System.out.println(video_url);
				driver.navigate().back();
				Synchronization.implicitWait(driver, 30);

				/**Video's*/
		/*		
				if (lstTestData.get(5).contentEquals(video_url))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + lstTestData.get(5)+ "Video's URL should be redirect to :"+ lstTestData.get(5) +Extent_Reports.logActual + "Actual redirected URL is :"+ video_url );
				}	
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + lstTestData.get(5)+ "Video's URL should be redirect to :"+ lstTestData.get(5) +Extent_Reports.logActual + "Actual redirected URL is :"+ video_url);

				}
						
		*/					
					 }
			 catch(Exception exc)
			 {
				 System.out.println(exc.getMessage());
			 }
			
			driver.close(); 
			
			return null;
		}
	
	
	//------------------------Verify for Metadata Enhancements  in Recently Added Section in Full Episodes Landing Page (DBB-3727) ------------------------			
	@Test
	  public PGAllVideosPage Verify_Metadata_Enhancements( ) throws InterruptedException, FilloException 
	  {
			
		//Launching Browser with valid URL.
		     driver.get(lstTestData.get(0));
		     try {
					//screenshotExtension=Extent_Reports.getScreenshot(driver);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		//Reading Objects
		try
		 {
			objEpisodes = Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
			objEpisodes.click();
			Synchronization.implicitWait(driver, 50);
			
			
						
			objshow_Name=Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
			Show_Name = objshow_Name.getAttribute("innerHTML");
			System.out.println(Show_Name);
	/*		
			if (objshow_Name.isDisplayed())
			{
				
				Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + "The metadata  should reflect show name on the first line"+ Show_Name +"':"+ Extent_Reports.logActual + "The metadata  should reflect show name on the first line"+ Show_Name );
			}	
		     
			else
			{
				Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + "The metadata  should reflect show name on the first line"+ Show_Name +"':"+ Extent_Reports.logActual + "The metadata  should reflect show name on the first line"+ Show_Name);

			}	
			
	*/		
			objepisode_Title=Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
			Show_Title = objshow_Name.getAttribute("innerHTML");
			System.out.println(Show_Title);
			
	/*		if (objepisode_Title.isDisplayed())
			{
				Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + "The metadata  Show Title should reflect show name on the Second line"+ Show_Title +"':"+ Extent_Reports.logActual + "The metadata  Show Title should reflect show name on the Second line"+ Show_Title );
			}	
			else
			{
				Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + "The metadata  Show Titleshould reflect show name on the Second line"+ Show_Title +"':"+ Extent_Reports.logActual + "The metadata  Show Title should reflect show name on the Second line"+ Show_Title);

			}	
			
	*/		objepisode_Date=Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
			Show_Date = objshow_Name.getAttribute("innerHTML");
			System.out.println(Show_Date);
	/*		if (objepisode_Date.isDisplayed())
			{
				Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + "The metadata  Show Date should reflect show name on the third line"+ Show_Date +"':"+ Extent_Reports.logActual + "The metadata  Show Date should reflect show name on the third line"+ Show_Date );
			}	
			else
			{
				Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected + "The metadata  Show Date should reflect show name on the third line"+ Show_Date +"':"+ Extent_Reports.logActual + "The metadata  Show Date should reflect show name on the third line" + Show_Date);

			}	
	*/					
			
	 }
		
		 catch(Exception exc)
		 {
			 System.out.println(exc.getMessage());
		 }
		
		driver.close(); 
		
		return null;
	}

	  
	//------------------------ Verify Episodes are sorted by Air Date in All Videos Page (NBCRESP-1438) ------------------------			
		@Test
		  public PGAllVideosPage Verify_Episodes_Sorted( ) throws InterruptedException, FilloException 
		  {
				
			//Launching Browser with valid URL.
			     driver.get(lstTestData.get(0));
			     try {
						//screenshotExtension=Extent_Reports.getScreenshot(driver);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			//Reading Objects
			try
			 {
				objEpisodes = Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
				objEpisodes.click();
				Synchronization.implicitWait(driver, 50);
			//	SimpleDateFormat formatter = new SimpleDateFormat("mm/dd/yy");
				arr = new ArrayList<String>();
				list = Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13));
				for(int i=0;i<list.size();i++){
					arr.add(list.get(i).getAttribute("innerHTML"));
				}
				
				System.out.println("Before sorting: " + arr);
			//	Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected + "Before sorting episodes are sorted by Air date "+ arr);
			//	Collections.sort(arr);
			//	System.out.println("After sorting: " + arr);
			// Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logActual+ "Before sorting episodes are sorted by Air date "+ arr);
				
		
			 }	
			
			 catch(Exception exc)
			 {
				 System.out.println(exc.getMessage());
			 }
			
			driver.close(); 
			
			return null;
		}

					 
				


}
