package com.nbcd.Pages;

import java.net.MalformedURLException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Utilities;
import com.relevantcodes.extentreports.LogStatus;

public class PGAuthpage extends GetWebDriverInstance {
	
	private static WebDriver driver;
	String sql;
	protected static String showDetails;
	DatabaseFunction db = new DatabaseFunction();
	public List<String> lstObject,lstTestData;
	String sqlQry,Status;
	WebElement objShowMenu,objShowVideoName,objAuthVideolink,objTVProvider;
	//,objTwitterDescription,objTwitterImage;
	//=================================================================================================================================================================================
	//Constructor to initialize all the Page Objects 
	public PGAuthpage(String Browser) 
	{      
		try 
			{
				
				this.driver = GetWebDriverInstance.getBrowser(Browser);
				lstTestData=db.getTestDataObject("Select * from AuthPage","Input");
				lstObject=db.getTestDataObject("Select * from AuthPage","ObjectRepository");
			} 
			catch (MalformedURLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
					
					
		}
	
	//========================================================================BUSINESS VALIDATION LOGIC=================================================
	@Test
	  public PGAuthpage AuthVideoplayvalidation( ) throws InterruptedException, FilloException 
	  {
		
		//Launching Browser with valid URL.
		     driver.get(lstTestData.get(0));
		
		//Reading Objects
		try
		 {
	
			//objTwitterDescription=Utilities.returnElement(driver,lstObject.get(14),lstObject.get(13));
			//objTwitterImage=Utilities.returnElement(driver,lstObject.get(17),lstObject.get(16));
			
	
			
		/*	if (lstTestData.get(1).equalsIgnoreCase(objTwitterCard.getAttribute("content")))
			{
				Extent_Reports.logger.log(LogStatus.PASS,"Expected Result for '"+lstObject.get(0) +"':"+lstTestData.get(1) +"\n"+"Actual Result for '"+lstObject.get(0) +"':"+objTwitterCard.getAttribute("content"));
			}
			else
			{
				Extent_Reports.logger.log(LogStatus.FAIL,"Expected Result for '"+lstObject.get(0) +"':"+lstTestData.get(1) +"\n"+"Actual Result for '"+lstObject.get(0) +"':"+objTwitterCard.getAttribute("content"));

			}
		*/
			objShowMenu =Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
			objShowMenu.click();
			Extent_Reports.logger.log(LogStatus.FAIL,"Expected Result for '"+lstObject.get(0) +"':"+lstTestData.get(1) +"\n"+"Actual Result for '"+lstObject.get(0) +"':"+objShowMenu.getAttribute("content"));
			objShowVideoName=Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
			objShowVideoName.click();
			Extent_Reports.logger.log(LogStatus.FAIL,"Expected Result for '"+lstObject.get(0) +"':"+lstTestData.get(1) +"\n"+"Actual Result for '"+lstObject.get(0) +"':"+objShowVideoName.getAttribute("content"));
			objAuthVideolink=Utilities.returnElement(driver,lstObject.get(8),lstObject.get(7));
			objAuthVideolink.click();
			Extent_Reports.logger.log(LogStatus.FAIL,"Expected Result for '"+lstObject.get(0) +"':"+lstTestData.get(1) +"\n"+"Actual Result for '"+lstObject.get(0) +"':"+objAuthVideolink.getAttribute("content"));
			objTVProvider=Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
			objTVProvider.click();
			Extent_Reports.logger.log(LogStatus.FAIL,"Expected Result for '"+lstObject.get(0) +"':"+lstTestData.get(1) +"\n"+"Actual Result for '"+lstObject.get(0) +"':"+objTVProvider.getAttribute("content"));
			
			
			
			
		 }
		 catch(Exception exc)
		 {
			 System.out.println(exc.getMessage());
		 }
		
		driver.close(); 
		
		return null;
	
	  }
}
