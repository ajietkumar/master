package com.nbcd.Pages;

import java.net.MalformedURLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;
import com.nbcd.GenericLib.Utilities;
import com.relevantcodes.extentreports.LogStatus;

public class PGAllShowsPage {
	
	//=========================================Variables=================================================================================
	private static WebDriver driver;
	String sql;
	protected static String showDetails;
	DatabaseFunction db = new DatabaseFunction();
	public List<String> lstObject,lstTestData;
	static String screenshotExtension;
	String sqlQry,Status,strResultText;
	WebElement objShows,objAllShows,objAllShowspageTitle,objctiveSubTab,objShowImage,objShowTitle,objmetaDescription,objfooter;
	
	
//=================================================================================================================================================================================	
//Constructor to initialize all the Page Objects  
	public PGAllShowsPage(String Browser) 
	{      
		try 
			{
				
				this.driver = GetWebDriverInstance.getBrowser(Browser);
				lstTestData=db.getTestDataObject("Select * from LivePage","Input");
				lstObject=db.getTestDataObject("Select * from LivePage","ObjectRepository");
			} 
			catch (MalformedURLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
					
					
		}
//========================================================================BUSINESS VALIDATION LOGIC=================================================
	@Test
	  public PGAllShowsPage VerifyAllShowPageFunctionality( ) throws InterruptedException, FilloException 
	  {
		
			//Launching Browser with valid URL.
			     driver.get(lstTestData.get(0));
			     try
			     {
			     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Browser should Launch"+Extent_Reports.logActual+"Browser Launch is succesfull");
			     screenshotExtension=Extent_Reports.getScreenshot(driver);
			     }
			     catch(Exception exc)
				 {
					 System.out.println(exc.getMessage());
				 }
				
			//Reading Objects
			try
			 {
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				WebElement objShows =Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(1);
				objShows.click();
				Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Shows list Page should display"+ Extent_Reports.logActual+"Shows list page is displayed after Shows link is clicked from global navigation");
				screenshotExtension=Extent_Reports.getScreenshot(driver);
				
				//Click on All Shows link 
				objAllShows =Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
				objAllShows.click();
				Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"All Shows list Page should display"+ Extent_Reports.logActual+"All Shows list page is displayed after All Shows link is clicked from Shows list");
				
				//Validate Menu items from All Show page
				WebElement objShowMenuItem =Utilities.returnElements(driver,lstObject.get(8),lstObject.get(7)).get(1);
				if(objShowMenuItem.isDisplayed()) 
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: Shows should display"+ Extent_Reports.logActual+"Menu Items: Shows is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: Shows should display"+ Extent_Reports.logActual+"Menu Items: Shows is not displayed");
				}
				WebElement objEpisodeItem =Utilities.returnElements(driver,lstObject.get(8),lstObject.get(7)).get(2);
				if(objEpisodeItem.isDisplayed()) 
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: Episode should display"+ Extent_Reports.logActual+"Menu Items: Episode is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: Episode should display"+ Extent_Reports.logActual+"Menu Items: Episode is not displayed");
				}
				
				WebElement objSCHEDULEItem =Utilities.returnElements(driver,lstObject.get(8),lstObject.get(7)).get(3);
				if(objSCHEDULEItem.isDisplayed())  
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: SCHEDULE should display"+ Extent_Reports.logActual+"Menu Items: SCHEDULE is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: SCHEDULE should display"+ Extent_Reports.logActual+"Menu Items: SCHEDULE is not displayed");
				}
				WebElement objNEWSSPORTSItem =Utilities.returnElements(driver,lstObject.get(8),lstObject.get(7)).get(4);
				if(objNEWSSPORTSItem.isDisplayed())
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: NEWS & SPORTS should display"+ Extent_Reports.logActual+"Menu Items: NEWS & SPORTS is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: NEWS & SPORTS should display"+ Extent_Reports.logActual+"Menu Items: NEWS & SPORTS is not displayed");
				}
				
				WebElement objSHOPItem =Utilities.returnElements(driver,lstObject.get(8),lstObject.get(7)).get(5);
				if(objSHOPItem.isDisplayed()) 
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: SHOP should display"+ Extent_Reports.logActual+"Menu Items: SHOP is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: SHOP should display"+ Extent_Reports.logActual+"Menu Items: SHOP is not displayed");
				}
				
				WebElement objAPPItem =Utilities.returnElements(driver,lstObject.get(8),lstObject.get(7)).get(6);
				if(objAPPItem.isDisplayed())  
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: APP should display"+ Extent_Reports.logActual+"Menu Items: APP is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: APP should display"+ Extent_Reports.logActual+"Menu Items: APP is not displayed");
				}
				
				WebElement objLIVEItem =Utilities.returnElements(driver,lstObject.get(8),lstObject.get(7)).get(7);
				if(objLIVEItem.isDisplayed())  
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Menu Items: LIVE should display"+ Extent_Reports.logActual+"Menu Items: LIVE is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Menu Items: LIVE should display"+ Extent_Reports.logActual+"Menu Items: LIVE is not displayed");
				}
				screenshotExtension=Extent_Reports.getScreenshot(driver);
				
				//Validate All Shows page h1 heading
				objAllShowspageTitle = Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
				String txtShows = objAllShowspageTitle.getText();
				if(txtShows.contentEquals("SHOWS"))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Sub Heading should display as Shows"+ Extent_Reports.logActual+"Sub heading is displayed as :"+txtShows );
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Sub Heading should display as Shows"+ Extent_Reports.logActual+"Sub heading is not displayed as expected and is displaying as :"+txtShows );
				}
				
				//Validate Sub tabs under all shows page
				WebElement objAllShowsSub =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(0);
				String AllSubTab = objAllShowsSub.getText();
				if(AllSubTab.contentEquals("all"))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Sub Menu Items: All should display"+ Extent_Reports.logActual+"Sub Menu Items: All is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Sub Menu Items: All should display"+ Extent_Reports.logActual+"Sub Menu Items: All is not displayed");
				}
				
				WebElement objCurrentShowsSub =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(0);
				String CurrentSubTab  = objCurrentShowsSub.getText();
				if(CurrentSubTab.contentEquals("current"))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Sub Menu Items: Current should display"+ Extent_Reports.logActual+"Sub Menu Items: Current is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Sub Menu Items: Current should display"+ Extent_Reports.logActual+"Sub Menu Items: Current is not displayed");
				}
				
				WebElement objUpcomingShowsSub =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(0);
				String UpcomingSubTab  = objUpcomingShowsSub.getText();
				if(UpcomingSubTab.contentEquals("upcoming"))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Sub Menu Items: Upcoming should display"+ Extent_Reports.logActual+"Sub Menu Items: Upcoming is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Sub Menu Items: Upcoming should display"+ Extent_Reports.logActual+"Sub Menu Items: Upcoming is not displayed");
				}
				
				WebElement objthrowbackShowsSub =Utilities.returnElements(driver,lstObject.get(14),lstObject.get(13)).get(0);
				String throwbackSubTab  = objthrowbackShowsSub.getText();
				if(throwbackSubTab.contentEquals("throwback"))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Sub Menu Items: Throwback should display"+ Extent_Reports.logActual+"Sub Menu Items: Throwback is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Sub Menu Items: Throwback should display"+ Extent_Reports.logActual+"Sub Menu Items: Throwback is not displayed");
				}
				
				//Validate if color is changing when sub menu option is selected
				objctiveSubTab =Utilities.returnElement(driver,lstObject.get(17),lstObject.get(16));
				String colorActive = objctiveSubTab.getCssValue("color");
				System.out.println(colorActive);
				String color_hex[];  
				color_hex = colorActive.replace("rgba(", "").split(",");       
				String actual_hex = String.format("#%02x%02x%02x", Integer.parseInt(color_hex[0].trim()), Integer.parseInt(color_hex[1].trim()), Integer.parseInt(color_hex[2].trim()));
				System.out.println(actual_hex);
				if(actual_hex.contentEquals("00b2eb"))
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Color of selected should display as Blue"+ Extent_Reports.logActual+"Color of selected tab is displayed in Blue");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Color of selected should display as Blue"+ Extent_Reports.logActual+"Color of selected tab is not displayed in Blue");
				}
				
				//Meta Data
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				
				WebElement objShowImage = Utilities.returnElements(driver,lstObject.get(20),lstObject.get(19)).get(0);
				
				String strShowName = objShowImage.getAttribute("src");
				if(objShowImage.isDisplayed())
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Image of Show should display"+ Extent_Reports.logActual+"Image of show is displayed and link is "+strShowName);
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Image of Show should display"+ Extent_Reports.logActual+"Image of show is not displayed");
				}
				
				WebElement objShowTitle = Utilities.returnElements(driver,lstObject.get(23),lstObject.get(22)).get(0);
				String strShowTitle = objShowTitle.getText();
				if(objShowTitle.isDisplayed())
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Image of Show should display"+ Extent_Reports.logActual+"Image of show is displayed and the title is "+strShowTitle);
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Image of Show should display"+ Extent_Reports.logActual+"Image of show is not displayed");
				}
				
				WebElement objShowtune = Utilities.returnElements(driver,lstObject.get(26),lstObject.get(25)).get(0);
				String strShowtune = objShowTitle.getText();
				if(objShowtune.isDisplayed())
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Image of Show should display"+ Extent_Reports.logActual+"Tune details of show is displayed and the tune details are "+strShowtune);
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Image of Show should display"+ Extent_Reports.logActual+"Image of show is not displayed");
				}
				
				objfooter = Utilities.returnElement(driver,lstObject.get(35),lstObject.get(34));
				if(objfooter.isDisplayed())
				{
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Footer should display"+ Extent_Reports.logActual+"Footer is displayed");
				}
				else
				{
					Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Footer should display"+ Extent_Reports.logActual+"Footer is not displayed");
				}
				
				
			 }
			 catch(Exception exc)
			 {
				 System.out.println(exc.getMessage());
			 }
			
			driver.close(); 
			
			return null;
		} 
	
	//========================================================================BUSINESS VALIDATION LOGIC=================================================
		@Test
		  public PGAllShowsPage VerifyAllShowPageThrowback( ) throws InterruptedException, FilloException 
		  {
			
				//Launching Browser with valid URL.
				     driver.get(lstTestData.get(0));
				     try
				     {
				     Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Browser should Launch"+Extent_Reports.logActual+"Browser Launch is succesfull");
				     screenshotExtension=Extent_Reports.getScreenshot(driver);
				     }
				     catch(Exception exc)
					 {
						 System.out.println(exc.getMessage());
					 }
					
				//Reading Objects
				try
				 {
					driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
					WebElement objShows =Utilities.returnElements(driver,lstObject.get(2),lstObject.get(1)).get(1);
					objShows.click();
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Shows list Page should display"+ Extent_Reports.logActual+"Shows list page is displayed after Shows link is clicked from global navigation");
					screenshotExtension=Extent_Reports.getScreenshot(driver);
					
					//Click on All Shows link 
					objAllShows =Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
					objAllShows.click();
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"All Shows list Page should display"+ Extent_Reports.logActual+"All Shows list page is displayed after All Shows link is clicked from Shows list");
					screenshotExtension=Extent_Reports.getScreenshot(driver);
					
					//Throw back link display
					driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					/**List <WebElement> a = driver.findElements(By.cssSelector("li.tabs__tab__item a"));
					String aa = a.get(0).getText();
					System.out.println(aa);
					String aaa = a.get(1).getText();
					System.out.println(aaa);
					String aaaa = a.get(2).getText();
					System.out.println(aaaa);
					String aaaaa = a.get(3).getText();
					System.out.println(aaaaa);
					a.get(3).click();*/
					
					WebElement objSubTab =Utilities.returnElements(driver,lstObject.get(29),lstObject.get(28)).get(3);
					String throwbacklinktext = objSubTab.getText();
					if(objSubTab.isDisplayed())
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"ThrowBack subtab should display"+ Extent_Reports.logActual+"Throwback tab is displayed and the link name is "+throwbacklinktext);
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"ThrowBack subtab should display"+ Extent_Reports.logActual+"Throwback tab is not displayed");
					}
					
					
					
					//click on Throw back link
					objSubTab.click();
					Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"ThrowBack subtab should be clickable"+ Extent_Reports.logActual+"Throwback tab is clicked");
					
					//Validate meta data All Shows page h1 heading
					objAllShowspageTitle = Utilities.returnElement(driver,lstObject.get(11),lstObject.get(10));
					String txtShows = objAllShowspageTitle.getText();
					if(txtShows.contentEquals("SHOWS"))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Sub Heading should display as Shows"+ Extent_Reports.logActual+"Sub heading is displayed as :"+txtShows );
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Sub Heading should display as Shows"+ Extent_Reports.logActual+"Sub heading is not displayed as expected and is displaying as :"+txtShows );
					}
					
					//Validate meta data for title
					String strTitle = driver.getTitle();
					if(strTitle.contentEquals("Classic Throwback NBC Shows - NBC.com"))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Title should display as Classic Throwback NBC Shows - NBC.com"+ Extent_Reports.logActual+"Title is displayed as :"+strTitle );
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Title should display as Shows"+ Extent_Reports.logActual+"Title is not displayed as expected and is displaying as :"+strTitle );
					}
					
					//Validate meta data for Description
					objmetaDescription =  Utilities.returnElement(driver,lstObject.get(32),lstObject.get(31));
					String CompValTextDescription = objmetaDescription.getAttribute("content");
					System.out.println(objmetaDescription);
					String Textcompval = "Rediscover your favorite throwback shows. Watch full episodes and browse photos of classic TV shows on NBC.com";
					if(CompValTextDescription.contentEquals(Textcompval))
					{
						Extent_Reports.logger.log(LogStatus.PASS,Extent_Reports.logExpected+"Description should  be as expected"+ Extent_Reports.logActual+"Description is as expected and the text is :"+CompValTextDescription );
					}
					else
					{
						Extent_Reports.logger.log(LogStatus.FAIL,Extent_Reports.logExpected+"Description should  be as expected"+ Extent_Reports.logActual+"Title is not displayed as expected and is displaying as :"+CompValTextDescription );
					}
					
				 }
				 catch(Exception exc)
				 {
					 System.out.println(exc.getMessage());
				 }
				
				driver.close(); 
				
				return null;
			} 	
	
}
