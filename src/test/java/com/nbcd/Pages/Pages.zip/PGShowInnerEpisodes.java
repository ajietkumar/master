package com.nbcd.Pages;
import com.relevantcodes.extentreports.LogStatus;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.codoid.products.exception.FilloException;
import com.nbcd.GenericLib.DatabaseFunction;
import com.nbcd.GenericLib.Synchronization;
import com.nbcd.GenericLib.Utilities;
import java.net.MalformedURLException;
import java.util.Iterator;

import com.nbcd.GenericLib.Extent_Reports;
import com.nbcd.GenericLib.GetWebDriverInstance;

public class PGShowInnerEpisodes extends GetWebDriverInstance
{
	
	private static WebDriver driver;
	String sql;
	protected static String showDetails;
	DatabaseFunction db = new DatabaseFunction();
	
	public List<String> lstObject,lstTestData;
	String sqlQry,Status;
	WebElement objBodyAd;
	
//Constructor to initialize all the Page Objects  
	
	
	
	
	public PGShowInnerEpisodes(String Browser) 
	{      
		
		try 
		{
			
			this.driver = GetWebDriverInstance.getBrowser(Browser);
			//lstTestData=db.getTestDataObject("Select * from ShowInnerEpisode","Input");
			lstObject=db.getTestDataObject("Select * from ShowInnerEpisode","ObjectRepository");
		} 
		catch (MalformedURLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	//=========================================================================================================================
    @Test
	public  PGShowInnerEpisodes BodyAd( ) throws InterruptedException, FilloException 
		  {
    	 //Launching the URL
        	{
  			 
        	  driver.get("https://www.nbc.com/the-blacklist/episodes");
  			  Synchronization.implicitWait(driver, 5);
 			  System.out.print("out");
  			  WebElement objBodyAd= (WebElement) Utilities.returnElement(driver,lstObject.get(2),lstObject.get(1));
  			
  			if (objBodyAd.isDisplayed())
			  {
  				Extent_Reports.logger.log(LogStatus.PASS,"Body Ad is Displayed");	
  				 driver.close();

			  }
			  else
			  {
				Extent_Reports.logger.log(LogStatus.FAIL,"Body Ad is Not Displayed");
			 driver.close();
        	}
			return null;

		  }    
		  }
          
//==============================================================================================
  
@Test
public PGShowInnerEpisodes  RespNavBar( ) throws InterruptedException, FilloException 
		  {
   	 //Launching the URL
       	{
 			 
       	  driver.get("https://www.nbc.com/the-blacklist/episodes");
 			  Synchronization.implicitWait(driver, 5);
 			  System.out.print("out");
 			  WebElement objRespNavBar= (WebElement) Utilities.returnElement(driver,lstObject.get(5),lstObject.get(4));
 			
 			if (objRespNavBar.isDisplayed())
			  {
 				Extent_Reports.logger.log(LogStatus.PASS,"Navigation Bar is Displayed");
 				 driver.close();
			  }
			  else
			  {
				Extent_Reports.logger.log(LogStatus.FAIL,"Navigation Bar is Not Displayed");
			 driver.close();
			  }
			return null;

       	}
		  }}
		 

//===================================================================================================================================================
